#ifndef APP_H
#define APP_H

#include "GenericTypeDefs.h"

/** DECLARATIONS ***************************************************/
#define NUM_OF_PINS 7
#define OUTPUT_NUM	6
#define OUTPUT1	LATCbits.LATC5
#define	OUTPUT2	LATCbits.LATC4
#define	OUTPUT3	LATCbits.LATC3
#define OUTPUT4	LATCbits.LATC6
#define	OUTPUT5	LATBbits.LATB6
#define	OUTPUT6	LATBbits.LATB5
#define INPUT_NUM	1
#define	INPUT1	PORTCbits.RC0

#define OUTPUT_ON		1
#define OUTPUT_OFF		0

// EEPROM
//#define EEPROM_SAVE_NUM				5
//#define EEPROM_SAME_COUNT			3
#define EEPROM_ADR_OUTPUT_TOP_ADR	0x10
#define EEPROM_ADR_OUTPUT_TOP		0
#define EEPROM_ADR_OUTPUT1			0
#define EEPROM_ADR_OUTPUT2			1
#define EEPROM_ADR_OUTPUT3			2
#define EEPROM_ADR_OUTPUT4			3
#define EEPROM_ADR_OUTPUT5			4
#define EEPROM_ADR_OUTPUT6			5
#define EEPROM_ADR_INPUT_TOP_ADR	0x50
#define EEPROM_ADR_INPUT_TOP		6
#define EEPROM_ADR_INPUT1			0

#define EEPROM_DATA_SIZE			9
#define TYPE_INDEX					0
#define NUM_INDEX					1
#define INIT_DELAY_INDEX			2
#define BRIGHTNESS_INDEX			3
#define VALUE1_INDEX				4
#define VALUE2_INDEX				5
#define VALUE3_INDEX				6
#define VALUE4_INDEX				7
#define VALUE5_INDEX				8
//#define VALUE6_INDEX				9
//#define VALUE7_INDEX				9

#define OUTPUT_TYPE_MAX				7	// �o�̓^�C�v �ő�l
#define OUTPUT_TYPE_NONE			0	// ���ݒ�
#define OUTPUT_TYPE_ON				1	// ON
#define OUTPUT_TYPE_BLINK			2	// �_��
#define OUTPUT_TYPE_SLOW_BLINK		3	// ����
#define OUTPUT_TYPE_CANDLE			4	// ��炬
#define OUTPUT_TYPE_FLUORESCENT_LAMP	5	// �u����
#define OUTPUT_TYPE_MUZZLE_FLASH	6	// �}�Y���t���b�V��
#define OUTPUT_TYPE_ROTATIONG_LIGHT	7	// ��]��

#define INPUT_TYPE_MAX				4	// ���̓^�C�v �ő�l
#define INPUT_TYPE_NONE				0	// �ݒ�Ȃ�
#define INPUT_TYPE_ON				1	// ON�̂Ƃ��L��
#define INPUT_TYPE_OFF				2	// OFF�̂Ƃ��L��
#define INPUT_TYPE_TOGGLE_ON		3	// ON����邽�тɐݒ肪�g�O�������
#define INPUT_TYPE_TOGGLE_OFF		4	// OFF����邽�тɐݒ肪�g�O�������

#define SETUP_VAL_STRENGTH_MIN		1
#define SETUP_VAL_STRENGTH_MAX		5
#define SETUP_VAL_STRENGTH_DEFAULT	3
#define SETUP_VAL_STRENGTH_BRIGHTNESS_MUL	4	// (LED_DUTY_TABLE_NUM / SETUP_VAL_STRENGTH_MAX)�̒l��ݒ�
#define SETUP_VAL_SPEED_MIN			1
#define SETUP_VAL_SPEED_MAX			10
#define SETUP_VAL_SPEED_DEFAULT		5
#define SETUP_VAL_FREQUENCY_MIN		1
#define SETUP_VAL_FREQUENCY_MAX		5
#define SETUP_VAL_FREQUENCY_DEFAULT	3



#define N_ON    1		// normal ON
#define N_OFF   0		// normal OFF
#define R_ON    0		// reverse ON
#define R_OFF   1		// reverse OFF


extern BYTE sw_led_on_status;
extern BYTE led_on_counter[OUTPUT_NUM];	// LED�@ON�J�E���^
extern WORD led_time_counter[OUTPUT_NUM];	// LED ON/OFF���ԃJ�E���^
extern BYTE led_para_update_flag[OUTPUT_NUM];	// 

extern BYTE eeprom_data_sw;
extern BYTE eeprom_data[OUTPUT_NUM][EEPROM_DATA_SIZE];

extern BYTE buffur_clear_flag;

#endif //APP_H
