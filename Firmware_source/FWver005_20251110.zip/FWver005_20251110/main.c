//	�͌^�pLED������
//	ver 0.0.5	2025.11.10	�����x�����ԕs��C�� �^�C�}�J�E���^�̏������^�C�~���O���C��
//	ver 0.0.4	2025.10.06	EEPROM SW�ݒ�l�̃A�h���X�C��0x40->0x50
//	ver 0.0.3	2025.09.16	�ʎY
//	ver 0.0.2	2025.02.xx	����
//	ver 0.0.1	2025.01.17	����


/********************************************************************
 FileName:		main.c
 Dependencies:	See INCLUDES section
 Processor:		PIC18, PIC24, and PIC32 USB Microcontrollers
 Hardware:		This demo is natively intended to be used on Microchip USB demo
 				boards supported by the MCHPFSUSB stack.  See release notes for
 				support matrix.  This demo can be modified for use on other hardware
 				platforms.
 Complier:  	Microchip C18 (for PIC18), C30 (for PIC24), C32 (for PIC32)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�E for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS�ECONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
********************************************************************/

#ifndef MAIN_C
#define MAIN_C

/** INCLUDES *******************************************************/
#include <p18f14k50.h>
#include <timers.h>
//#include <string.h>
#include "./USB/usb.h"
#include "HardwareProfile.h"
#include "./USB/usb_function_hid.h"
#include "app.h"
#include "eeprom.h"
#include "l_lib.h"

/** CONFIGURATION **************************************************/
#pragma config CPUDIV = NOCLKDIV
#pragma config USBDIV = OFF
#pragma config FOSC   = HS
#pragma config PLLEN  = ON
#pragma config FCMEN  = OFF
#pragma config IESO   = OFF
#pragma config PWRTEN = OFF
#pragma config BOREN  = OFF
#pragma config BORV   = 30
#pragma config WDTEN  = OFF
#pragma config WDTPS  = 32768
#pragma config MCLRE  = OFF
#pragma config HFOFST = OFF
#pragma config STVREN = ON
#pragma config LVP    = OFF
#pragma config XINST  = OFF
#pragma config BBSIZ  = OFF
#pragma config CP0    = OFF
#pragma config CP1    = OFF
#pragma config CPB    = OFF
#pragma config WRT0   = OFF
#pragma config WRT1   = OFF
#pragma config WRTB   = OFF
#pragma config WRTC   = OFF
#pragma config EBTR0  = OFF
#pragma config EBTR1  = OFF
#pragma config EBTRB  = OFF

//#define DEVELOP_MODE

/** PRIVATE PROTOTYPES *********************************************/
static void InitializeSystem(void);
void ProcessIO(void);
void UserInit(void);
BYTE LED_duty_cal(BYTE p_duty_idx, WORD p_on_time, WORD p_now_time);
void YourHighPriorityISRCode();
void YourLowPriorityISRCode();



/* Timer0 1.0ms */
/* 1000us / ( 0.021us x 4 ) = 12000  48MHz = 1/48us = 0.021us */
/* 12000 / 1 = 12000    �v���X�P�[��=1*/
/* 0x10000 - 0x2EE0 = 0xD120    16bit�J�E���^*/
//#define WRITE_TIMER0_COUNT        0xD120        //Timer0�̎���
/* Timer0 0.1ms */
/* 100us / ( 0.021us x 4 ) = 1200  48MHz = 1/48us = 0.021us */
/* 1200 / 1 = 1200    �v���X�P�[��=1*/
/* 0x10000 - 0x04B0 = 0xFB50    16bit�J�E���^*/
#define WRITE_TIMER0_COUNT      0xFB50        //Timer0�̎���
#define WRITE_TIMER0_COUNT_L    0x50        //Timer0�̎���
#define WRITE_TIMER0_COUNT_H	0xFB        //Timer0�̎���
/* Timer1 1.0ms */
/* 1000us / ( 0.021us x 4 ) = 12000  48MHz = 1/48us = 0.021us */
/* 12000 / 1 = 12000    �v���X�P�[��=1*/
/* 0x10000 - 0x2EE0 = 0xD120    16bit�J�E���^*/
#define WRITE_TIMER1_COUNT      0xD120        //Timer1�̎���
#define WRITE_TIMER1_COUNT_L    0x20        //Timer1�̎���
#define WRITE_TIMER1_COUNT_H	0xD1        //Timer1�̎���




/** VARIABLES ******************************************************/
#pragma udata
#define VERSION_STR_LEN		5
char	c_version[]="0.0.5";
USB_HANDLE USBOutHandle = 0;
USB_HANDLE USBInHandle = 0;

BYTE sw_led_on_status = 0;
BYTE led_on_loop_counter[OUTPUT_NUM] = {0};	// LED�@ON �J��Ԃ��J�E���^
WORD led_time_counter[OUTPUT_NUM] = {0};	// LED ON/OFF���ԃJ�E���^
BYTE timer_led_time_counter = 0;
BYTE timer_led_time_counter_pre = 0;
WORD led_time_interval_counter[OUTPUT_NUM] = {0};
BYTE led_para_update_flag[OUTPUT_NUM] = {0};
WORD led_duty_speed[OUTPUT_NUM] = {0};
BYTE led_on_flash_counter[OUTPUT_NUM] = {0};	// LED�@ON FLASH�J�E���^
WORD led_flash_time_counter[OUTPUT_NUM];	// LED FLASH ���ԃJ�E���^

#define LED_MAX_DUTY 100
BYTE LED_Out_Duty[OUTPUT_NUM] = {0};
BYTE LED_Out_Duty_fix[OUTPUT_NUM] = {0};
BYTE LED_Out_Duty_min_random[OUTPUT_NUM] = {0};
//BYTE output_fix_pre[OUTPUT_NUM] = {0};
BYTE output_duty_count = 0;
WORD output_interval_count = 0;
#define OUTPUT_INTERVAL_COUNTER_MAX		60000	// 60�b
#define CANDLE_OUTPUT_INTERVAL 			1500	// �L�����h�����������
#define CANDLE_OUTPUT_INTERVAL_SPEED	150		// �L�����h�����������
#define CANDLE_OUTPUT_DUTY_SPEED		200		// �L�����h��Duty�ύX�����
#define FLUORESCENT_LAMP_OUTPUT_INTERVAL 		3500	// �u�������������
#define FLUORESCENT_LAMP_OUTPUT_INTERVAL_SPEED	500		// �u�����p�x�����
#define FLUORESCENT_LAMP_OUTPUT_DUTY_SPEED		200		// �u����Duty�ύX�����
#define MUZZLE_FLASH_OUTPUT_DUTY_SPEED		200			// �}�Y���t���b�V��Duty�ύX�����

BYTE eeprom_data_sw = 0;
BYTE eeprom_data[OUTPUT_NUM][EEPROM_DATA_SIZE];
BYTE eeprom_data_cp[EEPROM_DATA_SIZE];

#define LED_DUTY_TABLE_NUM 21
rom BYTE LED_DUTY_TABLE[LED_DUTY_TABLE_NUM] = {0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 22, 26, 31, 36, 42, 50, 65, 80, 100};

BYTE buffur_clear_flag = 0;
WORD init_delay_time_1s_timer = 0;
BYTE init_delay_time_counter[OUTPUT_NUM] = {0};

BYTE led_on_checkbox = 0xFF;

WORD w_tmp1;
WORD w_tmp2;
WORD w_tmp3;
//DWORD dw_tmp = 0;
WORD w_para1;
WORD w_para2;
WORD w_para3;
BYTE b_para1;
BYTE b_para2;
BYTE b_para3;
BYTE duty_max = 0;
//BYTE duty_min = 0;
BYTE duty_diff;

BYTE debug_ary1[16] = {0};
//BYTE debug_ary2[16] = {0};
//BYTE debug_ary3[16] = {0};

// usb�ł̑��M�Ɏg���o�b�t�@�͂����Ő錾
#pragma udata usbram2

unsigned char ReceivedDataBuffer[64];
unsigned char ToSendDataBuffer[64];

#pragma udata

/** VECTOR REMAPPING ***********************************************/
#if defined(__18CXX)
	//On PIC18 devices, addresses 0x00, 0x08, and 0x18 are used for
	//the reset, high priority interrupt, and low priority interrupt
	//vectors.  However, the current Microchip USB bootloader 
	//examples are intended to occupy addresses 0x00-0x7FF or
	//0x00-0xFFF depending on which bootloader is used.  Therefore,
	//the bootloader code remaps these vectors to new locations
	//as indicated below.  This remapping is only necessary if you
	//wish to program the hex file generated from this project with
	//the USB bootloader.  If no bootloader is used, edit the
	//usb_config.h file and comment out the following defines:
	//#define PROGRAMMABLE_WITH_USB_HID_BOOTLOADER
	//#define PROGRAMMABLE_WITH_USB_LEGACY_CUSTOM_CLASS_BOOTLOADER
	
	#if defined(PROGRAMMABLE_WITH_USB_HID_BOOTLOADER)
		#define REMAPPED_RESET_VECTOR_ADDRESS			0x1000
		#define REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x1008
		#define REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x1018
	#elif defined(PROGRAMMABLE_WITH_USB_MCHPUSB_BOOTLOADER)	
		#define REMAPPED_RESET_VECTOR_ADDRESS			0x800
		#define REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x808
		#define REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x818
	#else	
		#define REMAPPED_RESET_VECTOR_ADDRESS			0x00
		#define REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x08
		#define REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x18
	#endif
	
	#if defined(PROGRAMMABLE_WITH_USB_HID_BOOTLOADER)||defined(PROGRAMMABLE_WITH_USB_MCHPUSB_BOOTLOADER)
	extern void _startup (void);        // See c018i.c in your C18 compiler dir
	#pragma code REMAPPED_RESET_VECTOR = REMAPPED_RESET_VECTOR_ADDRESS
	void _reset (void)
	{
	    _asm goto _startup _endasm
	}
	#endif
	#pragma code REMAPPED_HIGH_INTERRUPT_VECTOR = REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS
	void Remapped_High_ISR (void)
	{
	     _asm goto YourHighPriorityISRCode _endasm
	}
	#pragma code REMAPPED_LOW_INTERRUPT_VECTOR = REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS
	void Remapped_Low_ISR (void)
	{
	     _asm goto YourLowPriorityISRCode _endasm
	}
	
	#if defined(PROGRAMMABLE_WITH_USB_HID_BOOTLOADER)||defined(PROGRAMMABLE_WITH_USB_MCHPUSB_BOOTLOADER)
	//Note: If this project is built while one of the bootloaders has
	//been defined, but then the output hex file is not programmed with
	//the bootloader, addresses 0x08 and 0x18 would end up programmed with 0xFFFF.
	//As a result, if an actual interrupt was enabled and occured, the PC would jump
	//to 0x08 (or 0x18) and would begin executing "0xFFFF" (unprogrammed space).  This
	//executes as nop instructions, but the PC would eventually reach the REMAPPED_RESET_VECTOR_ADDRESS
	//(0x1000 or 0x800, depending upon bootloader), and would execute the "goto _startup".  This
	//would effective reset the application.
	
	//To fix this situation, we should always deliberately place a 
	//"goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS" at address 0x08, and a
	//"goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS" at address 0x18.  When the output
	//hex file of this project is programmed with the bootloader, these sections do not
	//get bootloaded (as they overlap the bootloader space).  If the output hex file is not
	//programmed using the bootloader, then the below goto instructions do get programmed,
	//and the hex file still works like normal.  The below section is only required to fix this
	//scenario.
	#pragma code HIGH_INTERRUPT_VECTOR = 0x08
	void High_ISR (void)
	{
	     _asm goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS _endasm
	}
	#pragma code LOW_INTERRUPT_VECTOR = 0x18
	void Low_ISR (void)
	{
	     _asm goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS _endasm
	}
	#endif	//end of "#if defined(PROGRAMMABLE_WITH_USB_HID_BOOTLOADER)||defined(PROGRAMMABLE_WITH_USB_LEGACY_CUSTOM_CLASS_BOOTLOADER)"

	#pragma code
	
	
	//These are your actual interrupt handling routines.
	#pragma interrupt YourHighPriorityISRCode
	void YourHighPriorityISRCode()
	{
		//Check which interrupt flag caused the interrupt.
		//Service the interrupt
		//Clear the interrupt flag
		//Etc.
		BYTE fi;

        #if defined(USB_INTERRUPT)
	        USBDeviceTasks();
        #endif
	
		if(INTCONbits.TMR0IF == 1)
		{	// ��������0.3�`0.4ms
			INTCONbits.TMR0IF = 0;
			TMR0L = WRITE_TIMER0_COUNT_L;
			TMR0H = WRITE_TIMER0_COUNT_H;
//			WriteTimer0(WRITE_TIMER0_COUNT);

			output_duty_count++;
			if(output_duty_count >= LED_MAX_DUTY)
			{
				output_duty_count = 0;
				for(fi = 0; fi < OUTPUT_NUM; fi++)
				{
					LED_Out_Duty_fix[fi] = LED_Out_Duty[fi];
				}
			}
			for(fi = 0; fi < OUTPUT_NUM; fi++)
			{
				(output_duty_count >= LED_Out_Duty_fix[fi]) ? set_LED((fi+1),OUTPUT_OFF) : set_LED((fi+1),OUTPUT_ON);
			}
		}
	}	//This return will be a "retfie fast", since this is in a #pragma interrupt section 
	#pragma interruptlow YourLowPriorityISRCode
	void YourLowPriorityISRCode()
	{
		//Check which interrupt flag caused the interrupt.
		//Service the interrupt
		//Clear the interrupt flag
		//Etc.
		char ch = 0;
		BYTE fi;
	
#if 0
		if(INTCONbits.TMR0IF == 1)
		{
			INTCONbits.TMR0IF = 0;
			TMR0L = WRITE_TIMER0_COUNT_L;
			TMR0H = WRITE_TIMER0_COUNT_H;
//			WriteTimer0(WRITE_TIMER0_COUNT);

			output_duty_count++;
			if(output_duty_count >= LED_MAX_DUTY)
			{
				output_duty_count = 0;
			}
			for(fi = 0; fi < OUTPUT_NUM; fi++)
			{
				(output_duty_count >= LED_Out_Duty[fi]) ? set_LED((fi+1),OUTPUT_OFF) : set_LED((fi+1),OUTPUT_ON);
			}
		}
#endif
		if(PIR1bits.TMR1IF == 1)
		{
			PIR1bits.TMR1IF = 0;
			TMR1L = WRITE_TIMER1_COUNT_L;
			TMR1H = WRITE_TIMER1_COUNT_H;
//			WriteTimer1(WRITE_TIMER1_COUNT);

			output_interval_count++;
			if(output_interval_count >= OUTPUT_INTERVAL_COUNTER_MAX)
			{
				output_interval_count = 0;
			}

			timer_led_time_counter++;
//			for(fi=0; fi<OUTPUT_NUM; fi++)
//			{
//				led_time_counter[fi]++;
//			}

			init_delay_time_1s_timer++;
			if(init_delay_time_1s_timer >= 1000)
			{
				init_delay_time_1s_timer = 0;
				for(fi=0; fi<OUTPUT_NUM; fi++)
				{
					if(init_delay_time_counter[fi] > 0)
					{
						init_delay_time_counter[fi]--;
					}
				}
			}
		}
	}	//This return will be a "retfie", since this is in a #pragma interruptlow section 
#endif

#pragma code

/********************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *******************************************************************/
void main(void)
{   
    InitializeSystem();

    #if defined(USB_INTERRUPT)
        USBDeviceAttach();
    #endif

    while(1)
    {
        #if defined(USB_POLLING)
		// Check bus status and service USB interrupts.
        USBDeviceTasks(); // Interrupt or polling method.  If using polling, must call
        				  // this function periodically.  This function will take care
        				  // of processing and responding to SETUP transactions 
        				  // (such as during the enumeration process when you first
        				  // plug in).  USB hosts require that USB devices should accept
        				  // and process SETUP packets in a timely fashion.  Therefore,
        				  // when using polling, this function should be called 
        				  // frequently (such as once about every 100 microseconds) at any
        				  // time that a SETUP packet might reasonably be expected to
        				  // be sent by the host to your device.  In most cases, the
        				  // USBDeviceTasks() function does not take very long to
        				  // execute (~50 instruction cycles) before it returns.
        #endif
    				  

		// Application-specific tasks.
		// Application related code may be added here, or in the ProcessIO() function.
        ProcessIO();        
    }//end while
}//end main


/********************************************************************
 * Function:        static void InitializeSystem(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        InitializeSystem is a centralize initialization
 *                  routine. All required USB initialization routines
 *                  are called from here.
 *
 *                  User application initialization routine should
 *                  also be called from here.                  
 *
 * Note:            None
 *******************************************************************/
static void InitializeSystem(void)
{
    ADCON1 |= 0x0F;                 // Default all pins to digital

//	The USB specifications require that USB peripheral devices must never source
//	current onto the Vbus pin.  Additionally, USB peripherals should not source
//	current on D+ or D- when the host/hub is not actively powering the Vbus line.
//	When designing a self powered (as opposed to bus powered) USB peripheral
//	device, the firmware should make sure not to turn on the USB module and D+
//	or D- pull up resistor unless Vbus is actively powered.  Therefore, the
//	firmware needs some means to detect when Vbus is being powered by the host.
//	A 5V tolerant I/O pin can be connected to Vbus (through a resistor), and
// 	can be used to detect when Vbus is high (host actively powering), or low
//	(host is shut down or otherwise not supplying power).  The USB firmware
// 	can then periodically poll this I/O pin to know when it is okay to turn on
//	the USB module/D+/D- pull up resistor.  When designing a purely bus powered
//	peripheral device, it is not possible to source current on D+ or D- when the
//	host is not actively providing power on Vbus. Therefore, implementing this
//	bus sense feature is optional.  This firmware can be made to use this bus
//	sense feature by making sure "USE_USB_BUS_SENSE_IO" has been defined in the
//	HardwareProfile.h file.    
    #if defined(USE_USB_BUS_SENSE_IO)
    tris_usb_bus_sense = INPUT_PIN; // See HardwareProfile.h
    #endif
    
//	If the host PC sends a GetStatus (device) request, the firmware must respond
//	and let the host know if the USB peripheral device is currently bus powered
//	or self powered.  See chapter 9 in the official USB specifications for details
//	regarding this request.  If the peripheral device is capable of being both
//	self and bus powered, it should not return a hard coded value for this request.
//	Instead, firmware should check if it is currently self or bus powered, and
//	respond accordingly.  If the hardware has been configured like demonstrated
//	on the PICDEM FS USB Demo Board, an I/O pin can be polled to determine the
//	currently selected power source.  On the PICDEM FS USB Demo Board, "RA2" 
//	is used for	this purpose.  If using this feature, make sure "USE_SELF_POWER_SENSE_IO"
//	has been defined in HardwareProfile.h, and that an appropriate I/O pin has been mapped
//	to it in HardwareProfile.h.
    #if defined(USE_SELF_POWER_SENSE_IO)
    tris_self_power = INPUT_PIN;	// See HardwareProfile.h
    #endif
    
    UserInit();

    USBDeviceInit();	//usb_device.c.  Initializes USB module SFRs and firmware
    					//variables to known states.
}//end InitializeSystem



/******************************************************************************
 * Function:        void UserInit(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This routine should take care of all of the demo code
 *                  initialization that is required.
 *
 * Note:            
 *
 *****************************************************************************/
void UserInit(void)
{
	BYTE fi,fj;
	BYTE uc_temp = 0;

//	�|�[�g�̐ݒ�
	LATA = 0;
	LATB = 0;
	LATC = 0;
	//PORT A ******************************************************************************************
	//���ׂďo�� b5:RA5 b4:RA4 b3:RA3 b1:RA1 b0:RA0
	//RA0 = 
	//RA1 = 
	//RA3 = 
	//RA4 =
	//RA5 =
	TRISA = 0x00;
	//PORT B ******************************************************************************************
	//���ׂďo�� b7:RB7 b6:RB6 b5:RB5 b4:RB4
	//RB4 = 
	//RB5 = �o��6
	//RB6 = �o��5
	//RB7 = 
	TRISB = 0x00;
	//PORT C  ******************************************************************************************
	//RC0�̂ݓ��́A���͂��ׂďo�� b7:RC7 b6:RC6 b5:RC5 b4:RC4 b3:RC3 b2:RC2 b1:RC1 bit0:RC0
	//RC0 = ����1
	//RC1 = 
	//RC2 = 
	//RC3 = �o��3
	//RC4 = �o��2
	//RC5 = �o��1
	//RC6 = �o��4
	//RC7 = 
	TRISC = 0x01;

	ANSEL = 0x00;
	ANSELH = 0x00;	//�S�ăf�W�^��

	INTCON2bits.RABPU = 1;		//�����v���A�b�v�𖳌��ɂ���
//	INTCON2bits.RABPU = 0;	//�����v���A�b�v���g����悤�ɂ���
//	WPUBbits.WPUB4 = 1;
//	WPUBbits.WPUB5 = 1;
//	WPUBbits.WPUB6 = 1;
//	WPUBbits.WPUB7 = 1;

    USBOutHandle = 0;
    USBInHandle = 0;
	ReceivedDataBuffer[0] = 0;
	ToSendDataBuffer[0] = 0;

//	�^�C�}������
//	�^�C�}0�̏�����
//	T0CON = 0x88;
	OpenTimer0(TIMER_INT_ON & T0_16BIT & T0_SOURCE_INT & T0_PS_1_1);
	TMR0L = WRITE_TIMER0_COUNT_L;
	TMR0H = WRITE_TIMER0_COUNT_H;
//	WriteTimer0(WRITE_TIMER0_COUNT);
//	�^�C�}1�̏�����
//	T1CON = 0x81;
	OpenTimer1(TIMER_INT_ON & T1_16BIT_RW & T1_SOURCE_INT & T1_OSC1EN_OFF & T1_SYNC_EXT_OFF & T1_PS_1_1);
	TMR1L = WRITE_TIMER1_COUNT_L;
	TMR1H = WRITE_TIMER1_COUNT_H;
//	WriteTimer1(WRITE_TIMER1_COUNT);
//	�^�C�}2�̏����� TMR2
	T2CON = 0x04;
//	OpenTimer2(TIMER_INT_OFF & T2_PS_1_1 & T2_POST_1_1 );

	// EEPROM
	// �o�͐ݒ�ǂݍ���
	for(fi = 0; fi < OUTPUT_NUM; fi++)
	{
		for(fj = 0; fj < EEPROM_DATA_SIZE; fj++)
		{
			uc_temp = ReadEEPROM(EEPROM_ADR_OUTPUT_TOP_ADR+(fi*EEPROM_DATA_SIZE)+fj);
			//ReadEEPROM_Agree(((fi*EEPROM_DATA_SIZE)+fj)*EEPROM_SAVE_NUM, EEPROM_SAVE_NUM, EEPROM_SAME_COUNT, &uc_temp);
			eeprom_data[fi][fj] = uc_temp;
		}

		// �l�`�F�b�N
		if(eeprom_data[fi][TYPE_INDEX] > OUTPUT_TYPE_MAX)
		{
			eeprom_data[fi][TYPE_INDEX] = OUTPUT_TYPE_NONE;
			for(fj = (TYPE_INDEX+1); fj < EEPROM_DATA_SIZE; fj++)
			{
				eeprom_data[fi][fj] = 0;
			}
		}
	}
	// ���͓ǂݍ���
	uc_temp = ReadEEPROM(EEPROM_ADR_INPUT_TOP_ADR);
	if(uc_temp > INPUT_TYPE_MAX)
	{	// �l�`�F�b�N
		uc_temp = INPUT_TYPE_NONE;
	}
	eeprom_data_sw = uc_temp;
	

//	���荞�݊J�n
	RCONbits.IPEN = 1;		//���荞�ݗD��t����
//	INTCON2bits.TMR0IP = 0;	//�^�C�}0���ʃ��x�����荞�݂ɐݒ�
	INTCON2bits.TMR0IP = 1;	//�^�C�}0�����ʃ��x�����荞�݂ɐݒ�
	INTCONbits.TMR0IE = 1;	//�^�C�}0���荞�݋���
	IPR1bits.TMR1IP = 0;	//�^�C�}1���ʃ��x�����荞�݂ɐݒ�
//	IPR1bits.TMR1IP = 1;	//�^�C�}1�����ʃ��x�����荞�݂ɐݒ�
	PIE1bits.TMR1IE = 1;	//�^�C�}1���荞�݋���
	INTCONbits.GIEL = 1;	//��ʃ��x�����荞�݂̋���
//	INTCONbits.GIEH = 1;	//���ʃ��x�����荞�݂̋���
	INTCONbits.GIE = 1;

	// �o�b�t�@�������t���O�Z�b�g
	buffur_clear_flag = 1;

}//end UserInit


/********************************************************************
 * Function:        void ProcessIO(void)
 *	
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is a place holder for other user
 *                  routines. It is a mixture of both USB and
 *                  non-USB tasks.
 *
 * Note:            None
 *******************************************************************/
void ProcessIO(void)
{
	BYTE fi,fj;
	char tmp;
	BYTE b_tmp;
	BYTE light_count_check;

//LATBbits.LATB7 = ~LATBbits.LATB7;
//debug_ary1[0]++;

	Switch_Input();

	// �����Ƃ邽�߂����Ń^�C���J�E���g
	b_tmp = timer_led_time_counter - timer_led_time_counter_pre;
	for(fi=0;fi<OUTPUT_NUM;fi++)
	{
		led_time_counter[fi] += b_tmp;
	}
	if(timer_led_time_counter > 250)
	{
		timer_led_time_counter = 0;
	}
	timer_led_time_counter_pre = timer_led_time_counter;
	
	// ���̓`�F�b�N
	switch(eeprom_data_sw)
	{
		case INPUT_TYPE_NONE:
			sw_led_on_status = 1;
			//led_on_loop_counter = 0;
			//led_time_counter = 0;
			break;
		case INPUT_TYPE_ON:
			if(sw_now_fix == N_ON)
			{
				sw_led_on_status = 1;
			}
			else
			{
				buffur_clear_flag = 1;
				sw_led_on_status = 0;
			}
			break;
		case INPUT_TYPE_OFF:
			if(sw_now_fix == N_OFF)
			{
				sw_led_on_status = 1;
			}
			else
			{
				buffur_clear_flag = 1;
				sw_led_on_status = 0;
			}
			break;
//		case INPUT_TYPE_TOGGLE_ON:
//			break;
//		case INPUT_TYPE_TOGGLE_OFF:
//			break;
	}

	// �o�b�t�@�N���A
	if(buffur_clear_flag == 1)
	{
		buffur_clear_flag = 0;

		init_delay_time_1s_timer = 0;

		for(fi=0;fi<OUTPUT_NUM;fi++)
		{
			led_on_loop_counter[fi] = 0;
			led_time_counter[fi] = 0;
			led_para_update_flag[fi] = 0;
			led_on_flash_counter[fi] = 0;
			init_delay_time_counter[fi] = eeprom_data[EEPROM_ADR_OUTPUT_TOP+fi][INIT_DELAY_INDEX];
		}
	}
	

	// �o��
	for(fi = 0; fi < OUTPUT_NUM; fi++)
	{
		// ���񏈗�����s����EEPROM�f�[�^���R�s�[ ROM�팸��
		for(fj = 0; fj < EEPROM_DATA_SIZE; fj++)
		{
			eeprom_data_cp[fj] = eeprom_data[EEPROM_ADR_OUTPUT_TOP+fi][fj];
		}

		// �_���`�F�b�N
		light_count_check = 0;
		if(init_delay_time_counter[fi] == 0)
		{	// �����x�����Ԍo�ߍς�

			// �_���񐔃`�F�b�N
			if(eeprom_data_cp[NUM_INDEX] == 0 
				|| led_on_loop_counter[fi] < eeprom_data_cp[NUM_INDEX])
			{	// �_��
				light_count_check = 1;
			}
		}
		else
		{
			led_on_loop_counter[fi] = 0;
			led_time_counter[fi] = 0;
			led_para_update_flag[fi] = 0;
			led_on_flash_counter[fi] = 0;
		}

		// �_���`�F�b�N�{�b�N�X�`�F�b�N
		if((led_on_checkbox & (0x01 << fi)) == 0)
		{
			//sw_led_on_status = 0;
			light_count_check = 0;
		}

		if(sw_led_on_status == 0 || light_count_check == 0)
		{
			LED_Out_Duty[fi] = 0;
		}

		if(sw_led_on_status == 1 && light_count_check == 1)
		{
			switch(eeprom_data_cp[TYPE_INDEX])
			{
				case OUTPUT_TYPE_NONE:
					LED_Out_Duty[fi] = 0;
					break;
				case OUTPUT_TYPE_ON:
//					if(sw_led_on_status == 1 && light_count_check == 1)
//					{
						// ���邳
						b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX];
						if(b_para1 < LED_DUTY_TABLE_NUM)
						{
							LED_Out_Duty[fi] = LED_DUTY_TABLE[b_para1];
						}
						else
						{
							LED_Out_Duty[fi] = LED_MAX_DUTY;
						}
						//LED_Out_Duty[fi] = b_para1;
//					}
					break;
				case OUTPUT_TYPE_BLINK:
//					if(sw_led_on_status == 1 && light_count_check == 1)
//					{
						// �_������
						w_para1 = eeprom_data_cp[VALUE2_INDEX];
						w_para1 = (w_para1 << 8) + eeprom_data_cp[VALUE1_INDEX];
						// ��������
						w_para2 = eeprom_data_cp[VALUE4_INDEX];
						w_para2 = (w_para2 << 8) + eeprom_data_cp[VALUE3_INDEX];
						// ���邳
						b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX];
	
						if(led_time_counter[fi] <= w_para1)
						{
							if(b_para1 < LED_DUTY_TABLE_NUM)
							{
								LED_Out_Duty[fi] = LED_DUTY_TABLE[b_para1];
							}
							else
							{
								LED_Out_Duty[fi] = LED_MAX_DUTY;
							}
							//if(b_para1 > LED_MAX_DUTY)
							//{
							//	LED_Out_Duty[fi] = LED_MAX_DUTY;
							//}
							//else
							//{
							//	LED_Out_Duty[fi] = b_para1;
							//}
						}
						else if(led_time_counter[fi] < (w_para1+w_para2))
						{
							LED_Out_Duty[fi] = 0;
						}
						else
						{
							if(led_on_loop_counter[fi] < 0xFF)
							{
								led_on_loop_counter[fi]++;
							}
							led_time_counter[fi] = 0;
						}
//					}
					break;
				case OUTPUT_TYPE_SLOW_BLINK:
#ifndef DEVELOP_MODE
//					if(sw_led_on_status == 1 && light_count_check == 1)
//					{
						// ��������
						w_para1 = eeprom_data_cp[VALUE2_INDEX];
						w_para1 = (w_para1 << 8) + eeprom_data_cp[VALUE1_INDEX];
						// ��������
						w_para2 = eeprom_data_cp[VALUE4_INDEX];
						w_para2 = (w_para2 << 8) + eeprom_data_cp[VALUE3_INDEX];
						// ���邳
						b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX];
		
						if(led_time_counter[fi] <= w_para1)
						{
							b_para1 = LED_duty_cal(b_para1, w_para1, led_time_counter[fi]);
#if 0
							// Duty�擾
							if(b_para1 < LED_DUTY_TABLE_NUM)
							{
								b_para1 = LED_DUTY_TABLE[b_para1];
							}
							else
							{
								b_para1 = LED_MAX_DUTY;
							}
		
							w_tmp1 = w_para1 / 2;
							if(w_tmp1 > 0)
							{
								if(led_time_counter[fi] <= w_tmp1)
								{	// ���񂾂񖾂邭
		
									// �I�[�o�[�t���[�΍�
									w_tmp2 = w_tmp1 / 100;
									if(w_tmp2 > 0)
									{
										w_tmp1 = w_tmp1 / w_tmp2;
										w_tmp3 = led_time_counter[fi] / w_tmp2;
									}
									else
									{
										w_tmp3 = led_time_counter[fi];
									}
									b_para1 = (BYTE)((b_para1 * w_tmp3 / w_tmp1) & 0xFF);
								}
								else
								{	// ���񂾂�Â�
									// �I�[�o�[�t���[�΍�
									w_tmp2 = w_tmp1 / 100;
									if(w_tmp2 > 0)
									{
										w_tmp1 = w_tmp1 / w_tmp2;
										w_tmp3 = led_time_counter[fi] / w_tmp2;
									}
									else
									{
										w_tmp3 = led_time_counter[fi];
									}
									w_tmp2 = w_tmp1 - (w_tmp3 - w_tmp1);
									b_para1 = (BYTE)((b_para1 * w_tmp2 / w_tmp1) & 0xFF);
								}
							}
		
							if(b_para1 > LED_MAX_DUTY)
							{
								LED_Out_Duty[fi] = LED_MAX_DUTY;
							}
							else
							{
								LED_Out_Duty[fi] = b_para1;
							}
#endif
							LED_Out_Duty[fi] = b_para1;
						}
						else if(led_time_counter[fi] < (w_para1+w_para2))
						{
							LED_Out_Duty[fi] = 0;
						}
						else
						{
							if(led_on_loop_counter[fi] < 0xFF)
							{
								led_on_loop_counter[fi]++;
							}
							led_time_counter[fi] = 0;
						}
//					}
#endif
					break;
				case OUTPUT_TYPE_CANDLE:
#ifndef DEVELOP_MODE
//					if(sw_led_on_status == 1 && light_count_check == 1)
//					{
						// ����(���邳)
						b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX] * SETUP_VAL_STRENGTH_BRIGHTNESS_MUL;
						// Duty�擾
						if(b_para1 < LED_DUTY_TABLE_NUM)
						{
							duty_max = LED_DUTY_TABLE[b_para1];
						}
						else
						{
							duty_max = LED_MAX_DUTY;
						}
	
						// �񐔃`�F�b�N
//						if(light_count_check == 1)
//						{
							// ����
							b_para2 = eeprom_data_cp[VALUE1_INDEX];
							if(b_para2 < SETUP_VAL_SPEED_MIN || SETUP_VAL_SPEED_MAX < b_para2)
							{
								b_para2 = SETUP_VAL_SPEED_DEFAULT;
							}
	
							// �����_�������v�Z
							if(led_para_update_flag[fi] == 0)
							{
								led_para_update_flag[fi] = 1;
	
								w_para1 = CANDLE_OUTPUT_INTERVAL - (CANDLE_OUTPUT_INTERVAL_SPEED * b_para2);
								w_para2 = (((TMR2 % 10) + 1) * (10 * (SETUP_VAL_SPEED_MAX - b_para2 + 1)));
								led_time_interval_counter[fi] = (w_para1 + w_para2);
								LED_Out_Duty_min_random[fi] = (TMR2 % duty_max) + 1;
								w_tmp1 = (((TMR2 % 10) + 1) * 20);
								led_duty_speed[fi] = CANDLE_OUTPUT_DUTY_SPEED + (w_tmp1 * (SETUP_VAL_SPEED_MAX - b_para2 + 1));
							}
	
							if(led_time_counter[fi] <= led_duty_speed[fi])
							{
								w_tmp1 = led_duty_speed[fi] / 3;
								duty_diff = (duty_max - LED_Out_Duty_min_random[fi]);
								if(led_time_counter[fi] <= w_tmp1)
								{	// ���񂾂�Â�
									b_tmp = (BYTE)((led_time_counter[fi] * duty_diff) / w_tmp1);
									b_para1 = duty_max - b_tmp;
								}
								else
								{	// ���񂾂񖾂邭
									w_tmp3 = led_time_counter[fi] - w_tmp1;
									b_tmp = (BYTE)((w_tmp3 * duty_diff) / w_tmp1);
									b_para1 = duty_max - (duty_diff - b_tmp);
								}
	
								if(b_para1 > LED_MAX_DUTY)
								{
									LED_Out_Duty[fi] = LED_MAX_DUTY;
								}
								else
								{
									LED_Out_Duty[fi] = b_para1;
								}
							}
							else if(led_time_counter[fi] < led_time_interval_counter[fi])
							{
								LED_Out_Duty[fi] = duty_max;
							}
							else
							{
								if(led_on_loop_counter[fi] < 0xFF)
								{
									led_on_loop_counter[fi]++;
								}
								led_time_counter[fi] = 0;
	
								led_para_update_flag[fi] = 0;
							}
//						}
//						else
//						{
//							LED_Out_Duty[fi] = duty_max;
//						}
//					}
#endif
					break;
				case OUTPUT_TYPE_FLUORESCENT_LAMP:	// �u����
#ifndef DEVELOP_MODE
//					if(sw_led_on_status == 1 && light_count_check == 1)
//					{
						// ���邳
						b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX];
						// Duty�擾
						if(b_para1 < LED_DUTY_TABLE_NUM)
						{
							duty_max = LED_DUTY_TABLE[b_para1];
						}
						else
						{
							duty_max = LED_MAX_DUTY;
						}
	
						// �_���񐔃`�F�b�N
//						if(light_count_check == 1)
//						{
							// �p�x
							b_para2 = eeprom_data_cp[VALUE1_INDEX];
							if(b_para2 < SETUP_VAL_FREQUENCY_MIN || SETUP_VAL_FREQUENCY_MAX < b_para2)
							{
								b_para2 = SETUP_VAL_FREQUENCY_DEFAULT;
							}
	
							// �����_�������v�Z
							if(led_para_update_flag[fi] == 0)
							{
								led_para_update_flag[fi] = 1;
	
								w_para1 = FLUORESCENT_LAMP_OUTPUT_INTERVAL - (FLUORESCENT_LAMP_OUTPUT_INTERVAL_SPEED * b_para2);
								w_para2 = ((((TMR2 % 30) + 1) / b_para2) * 100);
								led_time_interval_counter[fi] = (w_para1 + w_para2);
								//LED_Out_Duty_min_random[fi] = (TMR2 % duty_max) + 1;
								//w_tmp1 = (((TMR2 % 10) + 1) * 20);
								//led_duty_speed[fi] = CANDLE_OUTPUT_DUTY_SPEED + (w_tmp1 * (SETUP_VAL_SPEED_MAX - b_para2 + 1));
	
								led_on_flash_counter[fi] = (TMR2 % 5);
								led_flash_time_counter[fi] = ((TMR2 % 50) + 1) * 10;
							}
	
							if(led_time_counter[fi] <= led_flash_time_counter[fi])
							{
								w_tmp1 = led_flash_time_counter[fi] / 2;
								if(led_time_counter[fi] <= w_tmp1)
								{	// �_��
									LED_Out_Duty[fi] = duty_max;
								}
								else
								{	// ����
									LED_Out_Duty[fi] = 0;
								}
							}
							else if(led_time_counter[fi] < led_time_interval_counter[fi])
							{
								if(led_on_flash_counter[fi] > 0)
								{
									led_on_flash_counter[fi]--;
									led_flash_time_counter[fi] = ((TMR2 % 10) + 1) * 100;
									led_time_counter[fi] = 0;
								}
								LED_Out_Duty[fi] = 1;
							}
							else
							{
								if(led_on_loop_counter[fi] < 0xFF)
								{
									led_on_loop_counter[fi]++;
								}
								led_time_counter[fi] = 0;
	
								led_para_update_flag[fi] = 0;
							}
//						}
//						else
//						{
//							LED_Out_Duty[fi] = duty_max;
//						}
//					}
#endif
					break;
				case OUTPUT_TYPE_MUZZLE_FLASH:
#ifndef DEVELOP_MODE
//					if(sw_led_on_status == 1)
//					{
						// ���邳
						b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX];
						// Duty�擾
						if(b_para1 < LED_DUTY_TABLE_NUM)
						{
							duty_max = LED_DUTY_TABLE[b_para1];
						}
						else
						{
							duty_max = LED_MAX_DUTY;
						}
	
						// �_���񐔃`�F�b�N
						if(light_count_check == 1)
						{
							// �ݒ�l�Z�b�g
							if(led_para_update_flag[fi] == 0)
							{
								led_para_update_flag[fi] = 1;
	
								// ��
								led_on_flash_counter[fi] = eeprom_data_cp[VALUE1_INDEX] - 1;
								// �_�ˑ��x�Ԋu����
								w_para1 = eeprom_data_cp[VALUE3_INDEX];
								w_para1 = (w_para1 << 8) + eeprom_data_cp[VALUE2_INDEX];
								led_time_interval_counter[fi] = w_para1;
								// �_�ˊԊu����
								w_para1 = eeprom_data_cp[VALUE5_INDEX];
								w_para1 = (w_para1 << 8) + eeprom_data_cp[VALUE4_INDEX];
								led_duty_speed[fi] = w_para1 + MUZZLE_FLASH_OUTPUT_DUTY_SPEED;
								// �_������
								led_flash_time_counter[fi] = MUZZLE_FLASH_OUTPUT_DUTY_SPEED;
								if(led_flash_time_counter[fi] > led_time_interval_counter[fi])
								{
									led_flash_time_counter[fi] = led_time_interval_counter[fi];
								}
							}
	
							if(led_time_counter[fi] <= led_flash_time_counter[fi])
							{
								w_tmp1 = led_flash_time_counter[fi] / 2;
								if(led_time_counter[fi] <= w_tmp1)
								{	// �_��
									LED_Out_Duty[fi] = duty_max;
								}
								else
								{	// ����
									LED_Out_Duty[fi] = 0;
								}
							}
							else if(led_on_flash_counter[fi] > 0)
							{
								if(led_time_counter[fi] >= led_time_interval_counter[fi])
								{
									led_on_flash_counter[fi]--;
									led_time_counter[fi] = 0;
								}
							}
							else if(led_time_counter[fi] < led_duty_speed[fi])
							{
								LED_Out_Duty[fi] = 0;
							}
							else
							{
								if(led_on_loop_counter[fi] < 0xFF)
								{
									led_on_loop_counter[fi]++;
								}
								led_time_counter[fi] = 0;
	
								led_para_update_flag[fi] = 0;
							}
						}
//					}
#endif
					break;
				case OUTPUT_TYPE_ROTATIONG_LIGHT:
#ifndef DEVELOP_MODE
					if(fi == 0 || fi == 3)
					{
//						if(sw_led_on_status == 1)
//						{
							// �_���񐔃`�F�b�N
//							if(light_count_check == 1)
//							{
								// �ݒ�l�Z�b�g
								if(led_para_update_flag[fi] == 0)
								{
									led_para_update_flag[fi] = 1;
		
									LED_Out_Duty[fi] = 0;
									LED_Out_Duty[fi+1] = 0;
									LED_Out_Duty[fi+2] = 0;
								}
	
								// ���邳
								b_para1 = eeprom_data_cp[BRIGHTNESS_INDEX];
								// ����
								b_para2 = eeprom_data_cp[VALUE1_INDEX];
								w_para1 = 100 + ((WORD)100 * (SETUP_VAL_SPEED_MAX - b_para2));
								//w_para1 = 200 * (SETUP_VAL_SPEED_MAX - b_para2 + 1);
								w_para2 = 0;
		
								if(led_time_counter[fi] <= w_para1)
								{
									b_para1 = LED_duty_cal(b_para1, w_para1, led_time_counter[fi]);
#if 0
									// Duty�擾
									if(b_para1 < LED_DUTY_TABLE_NUM)
									{
										b_para1 = LED_DUTY_TABLE[b_para1];
									}
									else
									{
										b_para1 = LED_MAX_DUTY;
									}
									w_tmp1 = w_para1 / 2;
									if(w_tmp1 > 0)
									{
										if(led_time_counter[fi] <= w_tmp1)
										{	// ���񂾂񖾂邭
		
											// �I�[�o�[�t���[�΍�
											w_tmp2 = w_tmp1 / 100;
											if(w_tmp2 > 0)
											{
												w_tmp1 = w_tmp1 / w_tmp2;
												w_tmp3 = led_time_counter[fi] / w_tmp2;
											}
											else
											{
												w_tmp3 = led_time_counter[fi];
											}
											b_para1 = (BYTE)((b_para1 * w_tmp3 / w_tmp1) & 0xFF);
										}
										else
										{	// ���񂾂�Â�
											// �I�[�o�[�t���[�΍�
											w_tmp2 = w_tmp1 / 100;
											if(w_tmp2 > 0)
											{
												w_tmp1 = w_tmp1 / w_tmp2;
												w_tmp3 = led_time_counter[fi] / w_tmp2;
											}
											else
											{
												w_tmp3 = led_time_counter[fi];
											}
											w_tmp2 = w_tmp1 - (w_tmp3 - w_tmp1);
											b_para1 = (BYTE)((b_para1 * w_tmp2 / w_tmp1) & 0xFF);
										}
									}
		
									if(b_para1 > LED_MAX_DUTY)
									{
										LED_Out_Duty[fi+led_on_flash_counter[fi]] = LED_MAX_DUTY;
									}
									else
									{
										LED_Out_Duty[fi+led_on_flash_counter[fi]] = b_para1;
									}
#endif
									LED_Out_Duty[fi+led_on_flash_counter[fi]] = b_para1;
								}
								else if(led_time_counter[fi] < (w_para1+w_para2))
								{
									LED_Out_Duty[fi+led_on_flash_counter[fi]] = 0;
								}
								else
								{
									led_time_counter[fi] = 0;
	
									led_on_flash_counter[fi]++;
									if(led_on_flash_counter[fi] >= 3)
									{
										led_on_flash_counter[fi] = 0;
	
										if(led_on_loop_counter[fi] < 0xFF)
										{
											led_on_loop_counter[fi]++;
										}
									}
								}
//							}
//							else
//							{
//								LED_Out_Duty[fi] = 0;
//								LED_Out_Duty[fi+1] = 0;
//								LED_Out_Duty[fi+2] = 0;
//							}
//						}
//						else
//						{
//							LED_Out_Duty[fi] = 0;
//							LED_Out_Duty[fi+1] = 0;
//							LED_Out_Duty[fi+2] = 0;
//						}
					}
#endif
					break;
			}
		}
		else
		{
			if(eeprom_data_cp[TYPE_INDEX] == OUTPUT_TYPE_ROTATIONG_LIGHT && (fi == 0 || fi == 3))
			{
				LED_Out_Duty[fi] = 0;
				LED_Out_Duty[fi+1] = 0;
				LED_Out_Duty[fi+2] = 0;
			}
		}
	}


    // User Application USB tasks
    if((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)) return;

//---------------------------------------------------------------------
//	USB�f�[�^�ʐM��
    if(!HIDRxHandleBusy(USBOutHandle))				//Check if data was received from the host.
    {
        switch(ReceivedDataBuffer[0])
        {
            case 0x56: // V=0x56 Get Firmware version
                ToSendDataBuffer[0] = 0x56;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Pushbutton State command.
				
				for( fi = 0; fi < VERSION_STR_LEN; fi++ )
				{
					ToSendDataBuffer[fi+1] = c_version[fi];
				}
				// �Ō��NULL������ݒ�
				ToSendDataBuffer[fi+1] = 0x00;

#if 0
				tmp = strlen(c_version);
				if( 0 < tmp && tmp <= (64-2) )
				{
					for( fi = 0; fi < VERSION_STR_LEN; fi++ )
					{
						ToSendDataBuffer[fi+1] = c_version[fi];
					}
					// �Ō��NULL������ݒ�
					ToSendDataBuffer[fi+1] = 0x00;
				}
				else
				{
					//�o�[�W����������ُ�
					ToSendDataBuffer[1] = 0x00;
				}
#endif
                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
			case 0x30:	// �ݒ�l�擾
				ToSendDataBuffer[0] = 0x30;
				ToSendDataBuffer[1] = 0x00;

				b_tmp = 1;
				// �o�͐ݒ�
				for(fi = 0; fi < OUTPUT_NUM; fi++)
				{
					for(fj = 0; fj < EEPROM_DATA_SIZE; fj++)
					{
						ToSendDataBuffer[b_tmp++] = eeprom_data[fi][fj];
					}
				}
				// ���͐ݒ�
				ToSendDataBuffer[b_tmp++] = eeprom_data_sw;
				// LED�_���`�F�b�N�{�b�N�X
				ToSendDataBuffer[b_tmp++] = led_on_checkbox;

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
			case 0x31:	// ���͐ݒ�
				ToSendDataBuffer[0] = 0x31;
				ToSendDataBuffer[1] = 0x00;

				if(ReceivedDataBuffer[1] == 0x55
					&& ReceivedDataBuffer[2] == 0xAA
					&& ReceivedDataBuffer[3] == 0xFF
					&& ReceivedDataBuffer[4] == 0xAA
					&& ReceivedDataBuffer[5] == 0x55)
				{
					if(ReceivedDataBuffer[6] <= INPUT_TYPE_MAX)
					{
						eeprom_data_sw = ReceivedDataBuffer[6];
						WriteEEPROM(EEPROM_ADR_INPUT_TOP_ADR, eeprom_data_sw);
						//WriteEEPROM_Agree(((EEPROM_ADR_INPUT1*EEPROM_DATA_SIZE)+0)*EEPROM_SAVE_NUM, ReceivedDataBuffer[6], EEPROM_SAVE_NUM);
					}
					else
					{
						ToSendDataBuffer[1] = 0xFF;	// NG
					}
				}
				else
				{
					ToSendDataBuffer[1] = 0xFF;	// NG
				}

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
			case 0x32:	// �o�͐ݒ�i�ʁj
				ToSendDataBuffer[0] = 0x32;
				ToSendDataBuffer[1] = 0x00;

				if(ReceivedDataBuffer[1] == 0x55
					&& ReceivedDataBuffer[2] == 0xAA
					&& ReceivedDataBuffer[3] == 0xFF
					&& ReceivedDataBuffer[4] == 0xAA
					&& ReceivedDataBuffer[5] == 0x55)
				{
					if(ReceivedDataBuffer[6] < OUTPUT_NUM && ReceivedDataBuffer[7] <= OUTPUT_TYPE_MAX)
					{
						for(fi = 0; fi < EEPROM_DATA_SIZE; fi++)
						{
							eeprom_data[EEPROM_ADR_OUTPUT_TOP+ReceivedDataBuffer[6]][fi] = ReceivedDataBuffer[7+fi];
							WriteEEPROM(EEPROM_ADR_OUTPUT_TOP_ADR+((EEPROM_ADR_OUTPUT_TOP+ReceivedDataBuffer[6])*EEPROM_DATA_SIZE)+fi, ReceivedDataBuffer[7+fi]);
							//WriteEEPROM_Agree((((EEPROM_ADR_OUTPUT_TOP+ReceivedDataBuffer[6])*EEPROM_DATA_SIZE)+fi)*EEPROM_SAVE_NUM, ReceivedDataBuffer[7+fi], EEPROM_SAVE_NUM);
						}
						// LED�_���`�F�b�N�{�b�N�X�ݒ�
						led_on_checkbox = ReceivedDataBuffer[7+EEPROM_DATA_SIZE];

						buffur_clear_flag = 1;
					}
					else
					{
						ToSendDataBuffer[1] = 0xFF;	// NG
					}
				}
				else
				{
					ToSendDataBuffer[1] = 0xFF;	// NG
				}

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
#if 0
			case 0x33:	// �o�͐ݒ�i�ꊇ�j
				ToSendDataBuffer[0] = 0x33;
				ToSendDataBuffer[1] = 0x00;

				if(ReceivedDataBuffer[1] == 0x55
					&& ReceivedDataBuffer[2] == 0xAA
					&& ReceivedDataBuffer[3] == 0xFF
					&& ReceivedDataBuffer[4] == 0xAA
					&& ReceivedDataBuffer[5] == 0x55)
				{
					// �f�[�^�`�F�b�N
					for(fi = 0; fi < OUTPUT_NUM; fi++)
					{
						if(ReceivedDataBuffer[6+(fi*EEPROM_DATA_SIZE)] <= OUTPUT_TYPE_MAX)
						{	// OK
						}
						else
						{	// NG
							ToSendDataBuffer[1] = 0xFF;	// NG
							break;
						}
					}

					// �`�F�b�NOK�H
					if(ToSendDataBuffer[1] == 0x00)
					{
						for(fi = 0; fi < OUTPUT_NUM; fi++)
						{
							for(fj = 0; fj < EEPROM_DATA_SIZE; fj++)
							{
								eeprom_data[EEPROM_ADR_OUTPUT_TOP+fi][fj] = ReceivedDataBuffer[6+(fi*EEPROM_DATA_SIZE)+fj];
								WriteEEPROM(EEPROM_ADR_OUTPUT_TOP_ADR+((EEPROM_ADR_OUTPUT_TOP+fi)*EEPROM_DATA_SIZE)+fj, ReceivedDataBuffer[6+(fi*EEPROM_DATA_SIZE)+fj]);
								//WriteEEPROM_Agree((((EEPROM_ADR_OUTPUT_TOP+fi)*EEPROM_DATA_SIZE)+fj)*EEPROM_SAVE_NUM, ReceivedDataBuffer[6+(fi*EEPROM_DATA_SIZE)+fj], EEPROM_SAVE_NUM);
							}
						}
					}
				}
				else
				{
					ToSendDataBuffer[1] = 0xFF;	// NG
				}

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
#endif
			case 0x55:	//�\�t�g���Z�b�g��������
				UCONbits.SUSPND = 0;		//Disable USB module
				UCON = 0x00;				//Disable USB module
				for(fi = 0; fi < 0xFF; fi++)
				{
					WREG = 0xFF;
					while(WREG)
					{
						WREG--;
						_asm
						bra	0	//Equivalent to bra $+2, which takes half as much code as 2 nop instructions
						bra	0	//Equivalent to bra $+2, which takes half as much code as 2 nop instructions
						_endasm	
					}
				}
				Reset();
				break;
#if 1	//DEBUG
            case 0x40:
                ToSendDataBuffer[0] = 0x40;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Pushbutton State command.

#if 1
				ToSendDataBuffer[1] = sw_now_fix;
#endif

#if 0
				ToSendDataBuffer[1] = debug_ary1[0];
				ToSendDataBuffer[2] = debug_ary1[1];
				ToSendDataBuffer[3] = debug_ary1[2];
				ToSendDataBuffer[4] = TMR2;
				//ToSendDataBuffer[4] = debug_ary1[3];
				ToSendDataBuffer[5] = debug_ary1[4];
				ToSendDataBuffer[6] = debug_ary1[5];
				ToSendDataBuffer[7] = debug_ary1[6];
				ToSendDataBuffer[8] = debug_ary1[7];
				ToSendDataBuffer[9] = debug_ary1[8];
				ToSendDataBuffer[10] = debug_ary1[9];
				ToSendDataBuffer[11] = debug_ary1[10];
				ToSendDataBuffer[12] = debug_ary1[11];
				ToSendDataBuffer[13] = debug_ary1[12];
				ToSendDataBuffer[14] = debug_ary1[13];
				ToSendDataBuffer[15] = debug_ary1[14];
				ToSendDataBuffer[16] = debug_ary1[15];
#endif
#if 0
				for(fi=0;fi<EEPROM_DATA_SIZE;fi++)
				{
					//ToSendDataBuffer[1+fi] = eeprom_data[0][fi];
					ToSendDataBuffer[1+EEPROM_DATA_SIZE+fi] = eeprom_data[0][fi];
				}
#endif

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
#if 0
            case 0x41:
                ToSendDataBuffer[0] = 0x41;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Remocon Data command.

#if 0
				ToSendDataBuffer[1] = debug_ary2[0];
				ToSendDataBuffer[2] = debug_ary2[1];
				ToSendDataBuffer[3] = debug_ary2[2];
				ToSendDataBuffer[4] = debug_ary2[3];
				ToSendDataBuffer[5] = debug_ary2[4];
				ToSendDataBuffer[6] = debug_ary2[5];
				ToSendDataBuffer[7] = debug_ary2[6];
				ToSendDataBuffer[8] = debug_ary2[7];
				ToSendDataBuffer[9] = debug_ary2[8];
				ToSendDataBuffer[10] = debug_ary2[9];
				ToSendDataBuffer[11] = debug_ary2[10];
				ToSendDataBuffer[12] = debug_ary2[11];
				ToSendDataBuffer[13] = debug_ary2[12];
				ToSendDataBuffer[14] = debug_ary2[13];
				ToSendDataBuffer[15] = debug_ary2[14];
				ToSendDataBuffer[16] = debug_ary2[15];
#else
				ToSendDataBuffer[1] = (BYTE)((led_time_counter[0] >> 8) & 0xFF);
				ToSendDataBuffer[2] = (BYTE)(led_time_counter[0] & 0xFF);
				ToSendDataBuffer[3] = debug_ary2[2];
				ToSendDataBuffer[4] = debug_ary2[3];
				ToSendDataBuffer[5] = debug_ary2[4];
				ToSendDataBuffer[6] = debug_ary2[5];
				ToSendDataBuffer[7] = debug_ary2[6];
				ToSendDataBuffer[8] = debug_ary2[7];
				ToSendDataBuffer[9] = debug_ary2[8];
				ToSendDataBuffer[10] = debug_ary2[9];
				ToSendDataBuffer[11] = debug_ary2[10];
				ToSendDataBuffer[12] = debug_ary2[11];
				ToSendDataBuffer[13] = debug_ary2[12];
				ToSendDataBuffer[14] = debug_ary2[13];
				ToSendDataBuffer[15] = debug_ary2[14];
				ToSendDataBuffer[16] = debug_ary2[15];
#endif
                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
#endif
#if 0
            case 0x42:
                ToSendDataBuffer[0] = 0x42;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Remocon Data command.
#if 0
				ToSendDataBuffer[1] = debug_ary3[0];
				ToSendDataBuffer[2] = debug_ary3[1];
				ToSendDataBuffer[3] = debug_ary3[2];
				ToSendDataBuffer[4] = debug_ary3[3];
				ToSendDataBuffer[5] = debug_ary3[4];
				ToSendDataBuffer[6] = debug_ary3[5];
				ToSendDataBuffer[7] = debug_ary3[6];
				ToSendDataBuffer[8] = debug_ary3[7];
				ToSendDataBuffer[9] = debug_ary3[8];
				ToSendDataBuffer[10] = debug_ary3[9];
				ToSendDataBuffer[11] = debug_ary3[10];
				ToSendDataBuffer[12] = debug_ary3[11];
				ToSendDataBuffer[13] = debug_ary3[12];
				ToSendDataBuffer[14] = debug_ary3[13];
				ToSendDataBuffer[15] = debug_ary3[14];
				ToSendDataBuffer[16] = debug_ary3[15];
#else
				for(fi=0;fi<EEPROM_DATA_SIZE;fi++)
				{
					ToSendDataBuffer[1+fi] = eeprom_data[0][fi];
					ToSendDataBuffer[1+EEPROM_DATA_SIZE+fi] = eeprom_data[1][fi];
				}
#endif
                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP4,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
#endif
#endif	//DEBUG
        }
         //Re-arm the OUT endpoint for the next packet
        USBOutHandle = HIDRxPacket(HID_EP4,(BYTE*)&ReceivedDataBuffer,64);
    }
}

BYTE LED_duty_cal(BYTE p_duty_idx, WORD p_on_time, WORD p_now_time)
{
	BYTE out_duty = 0;
	WORD w1, w2, w3;

	// Duty�擾
	if(p_duty_idx < LED_DUTY_TABLE_NUM)
	{
		out_duty = LED_DUTY_TABLE[p_duty_idx];
	}
	else
	{
		out_duty = LED_MAX_DUTY;
	}

	w1 = p_on_time / 2;
	if(w1 > 0)
	{
		if(p_now_time <= w1)
		{	// ���񂾂񖾂邭

			// �I�[�o�[�t���[�΍�
			w2 = w1 / 50;
			if(w2 > 0)
			{
				w1 = w1 / w2;
				w3 = p_now_time / w2;
			}
			else
			{
				w3 = p_now_time;
			}
			out_duty = (BYTE)((out_duty * w3 / w1) & 0xFF);
		}
		else
		{	// ���񂾂�Â�

			// �I�[�o�[�t���[�΍�
			w2 = w1 / 50;
			if(w2 > 0)
			{
				w1 = w1 / w2;
				w3 = p_now_time / w2;
			}
			else
			{
				w3 = p_now_time;
			}
			w2 = w1 - (w3 - w1);
			out_duty = (BYTE)((out_duty * w2 / w1) & 0xFF);
		}
	}

	if(out_duty > LED_MAX_DUTY)
	{
		out_duty = LED_MAX_DUTY;
	}
//	else
//	{
//		out_duty = out_duty;
//	}

	return out_duty;
}


// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************
// The USB firmware stack will call the callback functions USBCBxxx() in response to certain USB related
// events.  For example, if the host PC is powering down, it will stop sending out Start of Frame (SOF)
// packets to your device.  In response to this, all USB devices are supposed to decrease their power
// consumption from the USB Vbus to <2.5mA each.  The USB module detects this condition (which according
// to the USB specifications is 3+ms of no bus activity/SOF packets) and then calls the USBCBSuspend()
// function.  You should modify these callback functions to take appropriate actions for each of these
// conditions.  For example, in the USBCBSuspend(), you may wish to add code that will decrease power
// consumption from Vbus to <2.5mA (such as by clock switching, turning off LEDs, putting the
// microcontroller to sleep, etc.).  Then, in the USBCBWakeFromSuspend() function, you may then wish to
// add code that undoes the power saving things done in the USBCBSuspend() function.

// The USBCBSendResume() function is special, in that the USB stack will not automatically call this
// function.  This function is meant to be called from the application firmware instead.  See the
// additional comments near the function.

/******************************************************************************
 * Function:        void USBCBSuspend(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Call back that is invoked when a USB suspend is detected
 *
 * Note:            None
 *****************************************************************************/
void USBCBSuspend(void)
{
	//Example power saving code.  Insert appropriate code here for the desired
	//application behavior.  If the microcontroller will be put to sleep, a
	//process similar to that shown below may be used:
	
	//ConfigureIOPinsForLowPower();
	//SaveStateOfAllInterruptEnableBits();
	//DisableAllInterruptEnableBits();
	//EnableOnlyTheInterruptsWhichWillBeUsedToWakeTheMicro();	//should enable at least USBActivityIF as a wake source
	//Sleep();
	//RestoreStateOfAllPreviouslySavedInterruptEnableBits();	//Preferrably, this should be done in the USBCBWakeFromSuspend() function instead.
	//RestoreIOPinsToNormal();									//Preferrably, this should be done in the USBCBWakeFromSuspend() function instead.

	//IMPORTANT NOTE: Do not clear the USBActivityIF (ACTVIF) bit here.  This bit is 
	//cleared inside the usb_device.c file.  Clearing USBActivityIF here will cause 
	//things to not work as intended.	
	

    #if defined(__C30__)
    #if 0
        U1EIR = 0xFFFF;
        U1IR = 0xFFFF;
        U1OTGIR = 0xFFFF;
        IFS5bits.USB1IF = 0;
        IEC5bits.USB1IE = 1;
        U1OTGIEbits.ACTVIE = 1;
        U1OTGIRbits.ACTVIF = 1;
        Sleep();
    #endif
    #endif
}


/******************************************************************************
 * Function:        void _USB1Interrupt(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called when the USB interrupt bit is set
 *					In this example the interrupt is only used when the device
 *					goes to sleep when it receives a USB suspend command
 *
 * Note:            None
 *****************************************************************************/
#if 0
void __attribute__ ((interrupt)) _USB1Interrupt(void)
{
    #if !defined(self_powered)
        if(U1OTGIRbits.ACTVIF)
        {       
            IEC5bits.USB1IE = 0;
            U1OTGIEbits.ACTVIE = 0;
            IFS5bits.USB1IF = 0;
        
            //USBClearInterruptFlag(USBActivityIFReg,USBActivityIFBitNum);
            USBClearInterruptFlag(USBIdleIFReg,USBIdleIFBitNum);
            //USBSuspendControl = 0;
        }
    #endif
}
#endif

/******************************************************************************
 * Function:        void USBCBWakeFromSuspend(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The host may put USB peripheral devices in low power
 *					suspend mode (by "sending" 3+ms of idle).  Once in suspend
 *					mode, the host may wake the device back up by sending non-
 *					idle state signalling.
 *					
 *					This call back is invoked when a wakeup from USB suspend 
 *					is detected.
 *
 * Note:            None
 *****************************************************************************/
void USBCBWakeFromSuspend(void)
{
	// If clock switching or other power savings measures were taken when
	// executing the USBCBSuspend() function, now would be a good time to
	// switch back to normal full power run mode conditions.  The host allows
	// a few milliseconds of wakeup time, after which the device must be 
	// fully back to normal, and capable of receiving and processing USB
	// packets.  In order to do this, the USB module must receive proper
	// clocking (IE: 48MHz clock must be available to SIE for full speed USB
	// operation).
}

/********************************************************************
 * Function:        void USBCB_SOF_Handler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USB host sends out a SOF packet to full-speed
 *                  devices every 1 ms. This interrupt may be useful
 *                  for isochronous pipes. End designers should
 *                  implement callback routine as necessary.
 *
 * Note:            None
 *******************************************************************/
void USBCB_SOF_Handler(void)
{
    // No need to clear UIRbits.SOFIF to 0 here.
    // Callback caller is already doing that.
}

/*******************************************************************
 * Function:        void USBCBErrorHandler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The purpose of this callback is mainly for
 *                  debugging during development. Check UEIR to see
 *                  which error causes the interrupt.
 *
 * Note:            None
 *******************************************************************/
void USBCBErrorHandler(void)
{
    // No need to clear UEIR to 0 here.
    // Callback caller is already doing that.

	// Typically, user firmware does not need to do anything special
	// if a USB error occurs.  For example, if the host sends an OUT
	// packet to your device, but the packet gets corrupted (ex:
	// because of a bad connection, or the user unplugs the
	// USB cable during the transmission) this will typically set
	// one or more USB error interrupt flags.  Nothing specific
	// needs to be done however, since the SIE will automatically
	// send a "NAK" packet to the host.  In response to this, the
	// host will normally retry to send the packet again, and no
	// data loss occurs.  The system will typically recover
	// automatically, without the need for application firmware
	// intervention.
	
	// Nevertheless, this callback function is provided, such as
	// for debugging purposes.
}


/*******************************************************************
 * Function:        void USBCBCheckOtherReq(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        When SETUP packets arrive from the host, some
 * 					firmware must process the request and respond
 *					appropriately to fulfill the request.  Some of
 *					the SETUP packets will be for standard
 *					USB "chapter 9" (as in, fulfilling chapter 9 of
 *					the official USB specifications) requests, while
 *					others may be specific to the USB device class
 *					that is being implemented.  For example, a HID
 *					class device needs to be able to respond to
 *					"GET REPORT" type of requests.  This
 *					is not a standard USB chapter 9 request, and 
 *					therefore not handled by usb_device.c.  Instead
 *					this request should be handled by class specific 
 *					firmware, such as that contained in usb_function_hid.c.
 *
 * Note:            None
 *******************************************************************/
void USBCBCheckOtherReq(void)
{
    USBCheckHIDRequest();
}//end


/*******************************************************************
 * Function:        void USBCBStdSetDscHandler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USBCBStdSetDscHandler() callback function is
 *					called when a SETUP, bRequest: SET_DESCRIPTOR request
 *					arrives.  Typically SET_DESCRIPTOR requests are
 *					not used in most applications, and it is
 *					optional to support this type of request.
 *
 * Note:            None
 *******************************************************************/
void USBCBStdSetDscHandler(void)
{
    // Must claim session ownership if supporting this request
}//end


/*******************************************************************
 * Function:        void USBCBInitEP(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called when the device becomes
 *                  initialized, which occurs after the host sends a
 * 					SET_CONFIGURATION (wValue not = 0) request.  This 
 *					callback function should initialize the endpoints 
 *					for the device's usage according to the current 
 *					configuration.
 *
 * Note:            None
 *******************************************************************/
void USBCBInitEP(void)
{
    //enable the HID endpoint
    USBEnableEndpoint(HID_EP4,USB_OUT_ENABLED|USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
}

/********************************************************************
 * Function:        void USBCBSendResume(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USB specifications allow some types of USB
 * 					peripheral devices to wake up a host PC (such
 *					as if it is in a low power suspend to RAM state).
 *					This can be a very useful feature in some
 *					USB applications, such as an Infrared remote
 *					control	receiver.  If a user presses the "power"
 *					button on a remote control, it is nice that the
 *					IR receiver can detect this signalling, and then
 *					send a USB "command" to the PC to wake up.
 *					
 *					The USBCBSendResume() "callback" function is used
 *					to send this special USB signalling which wakes 
 *					up the PC.  This function may be called by
 *					application firmware to wake up the PC.  This
 *					function should only be called when:
 *					
 *					1.  The USB driver used on the host PC supports
 *						the remote wakeup capability.
 *					2.  The USB configuration descriptor indicates
 *						the device is remote wakeup capable in the
 *						bmAttributes field.
 *					3.  The USB host PC is currently sleeping,
 *						and has previously sent your device a SET 
 *						FEATURE setup packet which "armed" the
 *						remote wakeup capability.   
 *
 *					This callback should send a RESUME signal that
 *                  has the period of 1-15ms.
 *
 * Note:            Interrupt vs. Polling
 *                  -Primary clock
 *                  -Secondary clock ***** MAKE NOTES ABOUT THIS *******
 *                   > Can switch to primary first by calling USBCBWakeFromSuspend()
 
 *                  The modifiable section in this routine should be changed
 *                  to meet the application needs. Current implementation
 *                  temporary blocks other functions from executing for a
 *                  period of 1-13 ms depending on the core frequency.
 *
 *                  According to USB 2.0 specification section 7.1.7.7,
 *                  "The remote wakeup device must hold the resume signaling
 *                  for at lest 1 ms but for no more than 15 ms."
 *                  The idea here is to use a delay counter loop, using a
 *                  common value that would work over a wide range of core
 *                  frequencies.
 *                  That value selected is 1800. See table below:
 *                  ==========================================================
 *                  Core Freq(MHz)      MIP         RESUME Signal Period (ms)
 *                  ==========================================================
 *                      48              12          1.05
 *                       4              1           12.6
 *                  ==========================================================
 *                  * These timing could be incorrect when using code
 *                    optimization or extended instruction mode,
 *                    or when having other interrupts enabled.
 *                    Make sure to verify using the MPLAB SIM's Stopwatch
 *                    and verify the actual signal on an oscilloscope.
 *******************************************************************/
void USBCBSendResume(void)
{
    static WORD delay_count;
    
    USBResumeControl = 1;                // Start RESUME signaling
    
    delay_count = 1800U;                // Set RESUME line for 1-13 ms
    do
    {
        delay_count--;
    }while(delay_count);
    USBResumeControl = 0;
}


/*******************************************************************
 * Function:        BOOL USER_USB_CALLBACK_EVENT_HANDLER(
 *                        USB_EVENT event, void *pdata, WORD size)
 *
 * PreCondition:    None
 *
 * Input:           USB_EVENT event - the type of event
 *                  void *pdata - pointer to the event data
 *                  WORD size - size of the event data
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called from the USB stack to
 *                  notify a user application that a USB event
 *                  occured.  This callback is in interrupt context
 *                  when the USB_INTERRUPT option is selected.
 *
 * Note:            None
 *******************************************************************/
BOOL USER_USB_CALLBACK_EVENT_HANDLER(USB_EVENT event, void *pdata, WORD size)
{
    switch(event)
    {
        case EVENT_CONFIGURED: 
            USBCBInitEP();
            break;
        case EVENT_SET_DESCRIPTOR:
            USBCBStdSetDscHandler();
            break;
        case EVENT_EP0_REQUEST:
            USBCBCheckOtherReq();
            break;
        case EVENT_SOF:
            USBCB_SOF_Handler();
            break;
        case EVENT_SUSPEND:
            USBCBSuspend();
            break;
        case EVENT_RESUME:
            USBCBWakeFromSuspend();
            break;
        case EVENT_BUS_ERROR:
            USBCBErrorHandler();
            break;
        case EVENT_TRANSFER:
            Nop();
            break;
        default:
            break;
    }      
    return TRUE; 
}

/** EOF main.c *************************************************/
#endif
