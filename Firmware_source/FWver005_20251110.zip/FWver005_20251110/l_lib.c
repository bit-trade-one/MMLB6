#include <p18f14k50.h>
#include "app.h"
#include "l_lib.h"

BYTE sw_now_fix=0;
BYTE sw_now_fix_pre=0;
BYTE sw_press_on_cnt=0;
BYTE sw_press_off_cnt=0;

//#define LED_DUTY_TABLE_NUM 11
//rom BYTE LED_DUTY_TABLE[LED_DUTY_TABLE_NUM][2] = {{0,0}, {10,2}, {20,5}, {30,10}, {40,15}, {50,22}, {60,30}, {70,40}, {80,50}, {90,70}, {100,100}};
//#define LED_DUTY_TABLE_NUM 7
//unsigned char LED_DUTY_TABLE[LED_DUTY_TABLE_NUM][2] = {{0,0}, {10,2}, {20,5}, {30,10}, {50,30}, {75,60}, {100,100}};
//#define LED_DUTY_TABLE_NUM 6
//rom BYTE LED_DUTY_TABLE[LED_DUTY_TABLE_NUM][2] = {{0,0}, {20,5}, {40,15}, {60,30}, {80,50}, {100,100}};

//rom BYTE LED_DUTY_TABLE[LED_DUTY_TABLE_NUM][2] = {{0,0}, {6,6}, {9,12}, {11,18}, {13,26}, {15,36}, {16,42}, {17,50}, {18,65}, {19,80}, {20,100}};

void Switch_Input(void)
{
    BYTE fi, fj;
    BYTE sw_now;

    sw_now 	= INPUT1;

#if 1
	if(sw_now == R_ON)
    {
    	sw_press_on_cnt++;
        if( sw_press_on_cnt >= SW_ON_DEBOUNCE_TIME)
        {
        	sw_now_fix = N_ON;
            sw_press_on_cnt = SW_ON_DEBOUNCE_TIME;
        }
		sw_press_off_cnt = 0;
    }
    else
    {
        sw_press_off_cnt++;
        if(sw_press_off_cnt >= SW_OFF_DEBOUNCE_TIME)
        {
            sw_now_fix = N_OFF;
        	sw_press_off_cnt = SW_OFF_DEBOUNCE_TIME;
        }
		sw_press_on_cnt = 0;
    }

      // SW Push���̏����ǉ�
	if( sw_now_fix_pre == N_OFF && sw_now_fix == N_ON )
    {	// �O��=OFF  ����=ON
		if(eeprom_data_sw == INPUT_TYPE_TOGGLE_ON)
		{
			if(sw_led_on_status == 0)
			{
				buffur_clear_flag = 1;
				sw_led_on_status = 1;
			}
			else
			{
				sw_led_on_status = 0;
			}
		}
	}
    else if( sw_now_fix_pre == N_ON && sw_now_fix == N_OFF )
    {	// �O��=ON  ����=OFF
		if(eeprom_data_sw == INPUT_TYPE_TOGGLE_OFF)
		{
			if(sw_led_on_status == 0)
			{
				buffur_clear_flag = 1;
				sw_led_on_status = 1;
			}
			else
			{
				sw_led_on_status = 0;
			}
		}
	}

	// ����l�ۑ�
    sw_now_fix_pre = sw_now_fix;
#endif
#if 0
    for(fi = 0; fi < SW_NUM; fi++ )
    {
        if(sw_now[fi] == R_ON)
        {
            sw_press_on_cnt[fi]++;
            if( sw_press_on_cnt[fi] >= SW_ON_DEBOUNCE_TIME)
            {
                sw_now_fix[fi] = N_ON;
                sw_press_on_cnt[fi] = SW_ON_DEBOUNCE_TIME;
            }
			sw_press_off_cnt[fi] = 0;
        }
        else
        {
            sw_press_off_cnt[fi]++;
            if(sw_press_off_cnt[fi] >= SW_OFF_DEBOUNCE_TIME)
            {
                sw_now_fix[fi] = N_OFF;
                sw_press_off_cnt[fi] = SW_OFF_DEBOUNCE_TIME;
            }
			sw_press_on_cnt[fi] = 0;
        }

        // SW Push���̏����ǉ�
        if( sw_now_fix_pre[fi] == N_OFF && sw_now_fix[fi] == N_ON )
        {	// �O��=OFF  ����=ON
			if(fi == INPUT1_IDX && eeprom_data[EEPROM_ADR_INPUT_TOP+EEPROM_ADR_INPUT1][TYPE_INDEX] == INPUT_TYPE_TOGGLE_ON)
			{
				if(sw_led_on_status == 0)
				{
					sw_led_on_status = 1;
				}
				else
				{
					sw_led_on_status = 0;
					for(fj=0;fj<OUTPUT_NUM;fj++)
					{
						led_on_counter[fj] = 0;
						led_time_counter[fj] = 0;
						led_para_update_flag[fi] = 0;
					}
				}
			}
        }
        else if( sw_now_fix_pre[fi] == N_ON && sw_now_fix[fi] == N_OFF )
        {	// �O��=ON  ����=OFF
			if(fi == INPUT1_IDX && eeprom_data[EEPROM_ADR_INPUT_TOP+EEPROM_ADR_INPUT1][TYPE_INDEX] == INPUT_TYPE_TOGGLE_OFF)
			{
				if(sw_led_on_status == 0)
				{
					sw_led_on_status = 1;
				}
				else
				{
					sw_led_on_status = 0;
					for(fj=0;fj<OUTPUT_NUM;fj++)
					{
						led_on_counter[fj] = 0;
						led_time_counter[fj] = 0;
						led_para_update_flag[fi] = 0;
					}
				}
			}
        }

        // ����l�ۑ�
        sw_now_fix_pre[fi] = sw_now_fix[fi];
    }
#endif
}

void set_LED(BYTE no, BYTE onoff)
{
	if(onoff == 0 || onoff == 1)
	{
		switch(no)
		{
			case 1:		OUTPUT1 = onoff;	break;
			case 2:		OUTPUT2 = onoff;	break;
			case 3:		OUTPUT3 = onoff;	break;
			case 4:		OUTPUT4 = onoff;	break;
			case 5:		OUTPUT5 = onoff;	break;
			case 6:		OUTPUT6 = onoff;	break;
			default: break;
		}
	}	
}

#if 0
BYTE x_y(BYTE p_x)
{
	BYTE y_val = 0;
	BYTE fi, fj;
//	unsigned char idx = 0;
	int int_temp;

	if(p_x <= 100)
	{
#if 0
		for(fi = 1; fi< LED_DUTY_TABLE_NUM; fi++)
		{
			if(LED_DUTY_TABLE[fi][0] >= p_x)
			{
//				idx = fi;
				break;
			}
		}
#endif
#if 0
		y_val = (unsigned char)(((int)p_x -  LED_DUTY_TABLE[fi][0]) * (LED_DUTY_TABLE[fi][1] - LED_DUTY_TABLE[fi-1][1]) / (LED_DUTY_TABLE[fi][0] - LED_DUTY_TABLE[fi-1][0])) + LED_DUTY_TABLE[fi][1];
#endif
#if 0
		int_temp = (int)p_x -  LED_DUTY_TABLE[fi][0];
		int_temp = int_temp * (LED_DUTY_TABLE[fi][1] - LED_DUTY_TABLE[fi-1][1]);
		int_temp = int_temp / (LED_DUTY_TABLE[fi][0] - LED_DUTY_TABLE[fi-1][0]);
		int_temp = int_temp + LED_DUTY_TABLE[fi][1];
		y_val = (unsigned char)int_temp;
#endif
	}
	else
	{
		y_val = 100;
	}

	return y_val;
}
#endif


