namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.btn_soft_reset = new System.Windows.Forms.Button();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.lbl_FWVersion = new System.Windows.Forms.Label();
            this.gbx_setting_list = new System.Windows.Forms.GroupBox();
            this.dgv_pattern_set_list = new System.Windows.Forms.DataGridView();
            this.no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkbx_LED_ON = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pattern = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setting_value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbx_input = new System.Windows.Forms.GroupBox();
            this.btn_sw_setting_set = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbbx_sw_pattern = new System.Windows.Forms.ComboBox();
            this.gbx_output = new System.Windows.Forms.GroupBox();
            this.lbl_para6 = new System.Windows.Forms.Label();
            this.lbl_para5 = new System.Windows.Forms.Label();
            this.num_setup_val_init_delay = new System.Windows.Forms.NumericUpDown();
            this.num_setup_val_brightness_off = new System.Windows.Forms.NumericUpDown();
            this.num_setup_val_number = new System.Windows.Forms.NumericUpDown();
            this.num_setup_val_frequency = new System.Windows.Forms.NumericUpDown();
            this.num_setup_val_speed = new System.Windows.Forms.NumericUpDown();
            this.num_setup_val_strength = new System.Windows.Forms.NumericUpDown();
            this.num_setup_val_brightness = new System.Windows.Forms.NumericUpDown();
            this.lbl_para4 = new System.Windows.Forms.Label();
            this.lbl_para3 = new System.Windows.Forms.Label();
            this.chkbx_loop = new System.Windows.Forms.CheckBox();
            this.btn_output_setting_set = new System.Windows.Forms.Button();
            this.num_setup_val_off_time = new System.Windows.Forms.NumericUpDown();
            this.lbl_para2 = new System.Windows.Forms.Label();
            this.num_setup_val_on_time = new System.Windows.Forms.NumericUpDown();
            this.lbl_para1 = new System.Windows.Forms.Label();
            this.cmbbx_output_pattern = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbbx_output_no = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.colum_lbl = new System.Windows.Forms.Label();
            this.Debug_label3 = new System.Windows.Forms.Label();
            this.Debug_label4 = new System.Windows.Forms.Label();
            this.Debug_label2 = new System.Windows.Forms.Label();
            this.Debug_label1 = new System.Windows.Forms.Label();
            this.btn_setup_import = new System.Windows.Forms.Button();
            this.btn_setup_export = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btn_setup_init = new System.Windows.Forms.Button();
            this.pic_logo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            this.gbx_setting_list.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pattern_set_list)).BeginInit();
            this.gbx_input.SuspendLayout();
            this.gbx_output.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_init_delay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_brightness_off)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_frequency)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_strength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_brightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_off_time)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_on_time)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.Color.Transparent;
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(751, 322);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 502;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.Color.Transparent;
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(10, 322);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(296, 12);
            this.StatusBox_lbl2.TabIndex = 500;
            this.StatusBox_lbl2.Text = "LED Controller for Models Configuration Tool�N�����܂���";
            // 
            // btn_soft_reset
            // 
            this.btn_soft_reset.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_soft_reset.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_soft_reset.Location = new System.Drawing.Point(790, 283);
            this.btn_soft_reset.Name = "btn_soft_reset";
            this.btn_soft_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_soft_reset.TabIndex = 300;
            this.btn_soft_reset.Text = "Update";
            this.btn_soft_reset.UseVisualStyleBackColor = false;
            this.btn_soft_reset.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_C_pb.Image = global::LED_Controller_for_Models_CT.Properties.Resources.ON;
            this.Status_C_pb.Location = new System.Drawing.Point(838, 324);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_C_pb.TabIndex = 94;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_NC_pb.Image = global::LED_Controller_for_Models_CT.Properties.Resources.OFF;
            this.Status_NC_pb.Location = new System.Drawing.Point(838, 324);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_NC_pb.TabIndex = 95;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // lbl_FWVersion
            // 
            this.lbl_FWVersion.AutoSize = true;
            this.lbl_FWVersion.BackColor = System.Drawing.Color.Transparent;
            this.lbl_FWVersion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.lbl_FWVersion.Location = new System.Drawing.Point(750, 310);
            this.lbl_FWVersion.Name = "lbl_FWVersion";
            this.lbl_FWVersion.Size = new System.Drawing.Size(74, 12);
            this.lbl_FWVersion.TabIndex = 501;
            this.lbl_FWVersion.Text = "FW Version : ";
            // 
            // gbx_setting_list
            // 
            this.gbx_setting_list.BackColor = System.Drawing.SystemColors.Control;
            this.gbx_setting_list.Controls.Add(this.dgv_pattern_set_list);
            this.gbx_setting_list.Location = new System.Drawing.Point(200, 18);
            this.gbx_setting_list.Name = "gbx_setting_list";
            this.gbx_setting_list.Size = new System.Drawing.Size(620, 200);
            this.gbx_setting_list.TabIndex = 250;
            this.gbx_setting_list.TabStop = false;
            this.gbx_setting_list.Text = "�ݒ胊�X�g";
            // 
            // dgv_pattern_set_list
            // 
            this.dgv_pattern_set_list.AllowUserToAddRows = false;
            this.dgv_pattern_set_list.AllowUserToDeleteRows = false;
            this.dgv_pattern_set_list.AllowUserToResizeColumns = false;
            this.dgv_pattern_set_list.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_pattern_set_list.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_pattern_set_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pattern_set_list.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.no,
            this.chkbx_LED_ON,
            this.pattern,
            this.setting_value});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_pattern_set_list.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_pattern_set_list.Location = new System.Drawing.Point(10, 20);
            this.dgv_pattern_set_list.MultiSelect = false;
            this.dgv_pattern_set_list.Name = "dgv_pattern_set_list";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_pattern_set_list.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_pattern_set_list.RowHeadersVisible = false;
            this.dgv_pattern_set_list.RowTemplate.Height = 21;
            this.dgv_pattern_set_list.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_pattern_set_list.Size = new System.Drawing.Size(600, 170);
            this.dgv_pattern_set_list.TabIndex = 990;
            this.dgv_pattern_set_list.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_pattern_set_list_CellContentClick);
            // 
            // no
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.no.DefaultCellStyle = dataGridViewCellStyle2;
            this.no.HeaderText = "No.";
            this.no.Name = "no";
            this.no.ReadOnly = true;
            this.no.Width = 30;
            // 
            // chkbx_LED_ON
            // 
            this.chkbx_LED_ON.HeaderText = "";
            this.chkbx_LED_ON.Name = "chkbx_LED_ON";
            this.chkbx_LED_ON.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.chkbx_LED_ON.Width = 25;
            // 
            // pattern
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.pattern.DefaultCellStyle = dataGridViewCellStyle3;
            this.pattern.HeaderText = "�p�^�[��";
            this.pattern.Name = "pattern";
            this.pattern.ReadOnly = true;
            this.pattern.Width = 80;
            // 
            // setting_value
            // 
            this.setting_value.HeaderText = "�ݒ�l";
            this.setting_value.Name = "setting_value";
            this.setting_value.ReadOnly = true;
            this.setting_value.Width = 500;
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.Silver;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(665, 347);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(400, 150);
            this.listView1.TabIndex = 990;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 2;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "No.";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 35;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "�p�^�[��";
            this.columnHeader3.Width = 76;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "�ݒ�l";
            this.columnHeader4.Width = 500;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "";
            // 
            // gbx_input
            // 
            this.gbx_input.Controls.Add(this.btn_sw_setting_set);
            this.gbx_input.Controls.Add(this.label1);
            this.gbx_input.Controls.Add(this.cmbbx_sw_pattern);
            this.gbx_input.Location = new System.Drawing.Point(15, 15);
            this.gbx_input.Name = "gbx_input";
            this.gbx_input.Size = new System.Drawing.Size(200, 260);
            this.gbx_input.TabIndex = 100;
            this.gbx_input.TabStop = false;
            this.gbx_input.Text = "SW�ݒ�";
            // 
            // btn_sw_setting_set
            // 
            this.btn_sw_setting_set.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_sw_setting_set.Location = new System.Drawing.Point(40, 74);
            this.btn_sw_setting_set.Name = "btn_sw_setting_set";
            this.btn_sw_setting_set.Size = new System.Drawing.Size(120, 35);
            this.btn_sw_setting_set.TabIndex = 99;
            this.btn_sw_setting_set.Text = "�ݒ�";
            this.btn_sw_setting_set.UseVisualStyleBackColor = true;
            this.btn_sw_setting_set.Click += new System.EventHandler(this.btn_sw_setting_set_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(10, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "�p�^�[��";
            // 
            // cmbbx_sw_pattern
            // 
            this.cmbbx_sw_pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_sw_pattern.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbbx_sw_pattern.FormattingEnabled = true;
            this.cmbbx_sw_pattern.Location = new System.Drawing.Point(12, 38);
            this.cmbbx_sw_pattern.Name = "cmbbx_sw_pattern";
            this.cmbbx_sw_pattern.Size = new System.Drawing.Size(180, 23);
            this.cmbbx_sw_pattern.TabIndex = 2;
            // 
            // gbx_output
            // 
            this.gbx_output.Controls.Add(this.lbl_para6);
            this.gbx_output.Controls.Add(this.lbl_para5);
            this.gbx_output.Controls.Add(this.num_setup_val_init_delay);
            this.gbx_output.Controls.Add(this.num_setup_val_brightness_off);
            this.gbx_output.Controls.Add(this.num_setup_val_number);
            this.gbx_output.Controls.Add(this.num_setup_val_frequency);
            this.gbx_output.Controls.Add(this.num_setup_val_speed);
            this.gbx_output.Controls.Add(this.num_setup_val_strength);
            this.gbx_output.Controls.Add(this.num_setup_val_brightness);
            this.gbx_output.Controls.Add(this.lbl_para4);
            this.gbx_output.Controls.Add(this.lbl_para3);
            this.gbx_output.Controls.Add(this.chkbx_loop);
            this.gbx_output.Controls.Add(this.btn_output_setting_set);
            this.gbx_output.Controls.Add(this.num_setup_val_off_time);
            this.gbx_output.Controls.Add(this.lbl_para2);
            this.gbx_output.Controls.Add(this.gbx_setting_list);
            this.gbx_output.Controls.Add(this.num_setup_val_on_time);
            this.gbx_output.Controls.Add(this.lbl_para1);
            this.gbx_output.Controls.Add(this.cmbbx_output_pattern);
            this.gbx_output.Controls.Add(this.label3);
            this.gbx_output.Controls.Add(this.cmbbx_output_no);
            this.gbx_output.Controls.Add(this.label2);
            this.gbx_output.Location = new System.Drawing.Point(230, 15);
            this.gbx_output.Name = "gbx_output";
            this.gbx_output.Size = new System.Drawing.Size(830, 260);
            this.gbx_output.TabIndex = 200;
            this.gbx_output.TabStop = false;
            this.gbx_output.Text = "�o�͐ݒ�";
            // 
            // lbl_para6
            // 
            this.lbl_para6.Location = new System.Drawing.Point(10, 200);
            this.lbl_para6.Name = "lbl_para6";
            this.lbl_para6.Size = new System.Drawing.Size(105, 12);
            this.lbl_para6.TabIndex = 11;
            this.lbl_para6.Text = "�ݒ�l";
            // 
            // lbl_para5
            // 
            this.lbl_para5.Location = new System.Drawing.Point(10, 175);
            this.lbl_para5.Name = "lbl_para5";
            this.lbl_para5.Size = new System.Drawing.Size(105, 12);
            this.lbl_para5.TabIndex = 10;
            this.lbl_para5.Text = "�ݒ�l";
            // 
            // num_setup_val_init_delay
            // 
            this.num_setup_val_init_delay.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_init_delay.Location = new System.Drawing.Point(115, 95);
            this.num_setup_val_init_delay.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.num_setup_val_init_delay.Name = "num_setup_val_init_delay";
            this.num_setup_val_init_delay.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_init_delay.TabIndex = 20;
            this.num_setup_val_init_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // num_setup_val_brightness_off
            // 
            this.num_setup_val_brightness_off.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_brightness_off.Location = new System.Drawing.Point(115, 120);
            this.num_setup_val_brightness_off.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_setup_val_brightness_off.Name = "num_setup_val_brightness_off";
            this.num_setup_val_brightness_off.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_brightness_off.TabIndex = 22;
            this.num_setup_val_brightness_off.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_brightness_off.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // num_setup_val_number
            // 
            this.num_setup_val_number.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_number.Location = new System.Drawing.Point(419, 224);
            this.num_setup_val_number.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_setup_val_number.Name = "num_setup_val_number";
            this.num_setup_val_number.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_number.TabIndex = 28;
            this.num_setup_val_number.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_number.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // num_setup_val_frequency
            // 
            this.num_setup_val_frequency.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_frequency.Location = new System.Drawing.Point(343, 224);
            this.num_setup_val_frequency.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.num_setup_val_frequency.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_setup_val_frequency.Name = "num_setup_val_frequency";
            this.num_setup_val_frequency.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_frequency.TabIndex = 27;
            this.num_setup_val_frequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_frequency.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // num_setup_val_speed
            // 
            this.num_setup_val_speed.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_speed.Location = new System.Drawing.Point(267, 224);
            this.num_setup_val_speed.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.num_setup_val_speed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_setup_val_speed.Name = "num_setup_val_speed";
            this.num_setup_val_speed.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_speed.TabIndex = 26;
            this.num_setup_val_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_speed.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // num_setup_val_strength
            // 
            this.num_setup_val_strength.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_strength.Location = new System.Drawing.Point(191, 224);
            this.num_setup_val_strength.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.num_setup_val_strength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_setup_val_strength.Name = "num_setup_val_strength";
            this.num_setup_val_strength.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_strength.TabIndex = 25;
            this.num_setup_val_strength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_strength.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // num_setup_val_brightness
            // 
            this.num_setup_val_brightness.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_brightness.Location = new System.Drawing.Point(115, 120);
            this.num_setup_val_brightness.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.num_setup_val_brightness.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_setup_val_brightness.Name = "num_setup_val_brightness";
            this.num_setup_val_brightness.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_brightness.TabIndex = 21;
            this.num_setup_val_brightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_brightness.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lbl_para4
            // 
            this.lbl_para4.Location = new System.Drawing.Point(10, 150);
            this.lbl_para4.Name = "lbl_para4";
            this.lbl_para4.Size = new System.Drawing.Size(105, 12);
            this.lbl_para4.TabIndex = 9;
            this.lbl_para4.Text = "�ݒ�l";
            // 
            // lbl_para3
            // 
            this.lbl_para3.Location = new System.Drawing.Point(10, 125);
            this.lbl_para3.Name = "lbl_para3";
            this.lbl_para3.Size = new System.Drawing.Size(105, 12);
            this.lbl_para3.TabIndex = 8;
            this.lbl_para3.Text = "�ݒ�l";
            // 
            // chkbx_loop
            // 
            this.chkbx_loop.AutoSize = true;
            this.chkbx_loop.Location = new System.Drawing.Point(71, 77);
            this.chkbx_loop.Name = "chkbx_loop";
            this.chkbx_loop.Size = new System.Drawing.Size(15, 14);
            this.chkbx_loop.TabIndex = 6;
            this.chkbx_loop.UseVisualStyleBackColor = true;
            // 
            // btn_output_setting_set
            // 
            this.btn_output_setting_set.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_output_setting_set.Location = new System.Drawing.Point(44, 222);
            this.btn_output_setting_set.Name = "btn_output_setting_set";
            this.btn_output_setting_set.Size = new System.Drawing.Size(120, 28);
            this.btn_output_setting_set.TabIndex = 99;
            this.btn_output_setting_set.Text = "�ݒ�";
            this.btn_output_setting_set.UseVisualStyleBackColor = true;
            this.btn_output_setting_set.Click += new System.EventHandler(this.btn_output_setting_set_Click);
            // 
            // num_setup_val_off_time
            // 
            this.num_setup_val_off_time.DecimalPlaces = 2;
            this.num_setup_val_off_time.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_off_time.Increment = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            this.num_setup_val_off_time.Location = new System.Drawing.Point(115, 170);
            this.num_setup_val_off_time.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.num_setup_val_off_time.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            this.num_setup_val_off_time.Name = "num_setup_val_off_time";
            this.num_setup_val_off_time.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_off_time.TabIndex = 24;
            this.num_setup_val_off_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_off_time.Value = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            // 
            // lbl_para2
            // 
            this.lbl_para2.Location = new System.Drawing.Point(10, 100);
            this.lbl_para2.Name = "lbl_para2";
            this.lbl_para2.Size = new System.Drawing.Size(105, 12);
            this.lbl_para2.TabIndex = 7;
            this.lbl_para2.Text = "�ݒ�l";
            // 
            // num_setup_val_on_time
            // 
            this.num_setup_val_on_time.DecimalPlaces = 2;
            this.num_setup_val_on_time.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_setup_val_on_time.Increment = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            this.num_setup_val_on_time.Location = new System.Drawing.Point(115, 145);
            this.num_setup_val_on_time.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.num_setup_val_on_time.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            this.num_setup_val_on_time.Name = "num_setup_val_on_time";
            this.num_setup_val_on_time.Size = new System.Drawing.Size(70, 23);
            this.num_setup_val_on_time.TabIndex = 23;
            this.num_setup_val_on_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_setup_val_on_time.Value = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            // 
            // lbl_para1
            // 
            this.lbl_para1.Location = new System.Drawing.Point(10, 78);
            this.lbl_para1.Name = "lbl_para1";
            this.lbl_para1.Size = new System.Drawing.Size(55, 12);
            this.lbl_para1.TabIndex = 5;
            this.lbl_para1.Text = "�J��Ԃ�";
            // 
            // cmbbx_output_pattern
            // 
            this.cmbbx_output_pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_output_pattern.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbbx_output_pattern.FormattingEnabled = true;
            this.cmbbx_output_pattern.Location = new System.Drawing.Point(65, 45);
            this.cmbbx_output_pattern.Name = "cmbbx_output_pattern";
            this.cmbbx_output_pattern.Size = new System.Drawing.Size(121, 23);
            this.cmbbx_output_pattern.TabIndex = 4;
            this.cmbbx_output_pattern.SelectedIndexChanged += new System.EventHandler(this.cmbbx_output_pattern_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(10, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "�p�^�[��";
            // 
            // cmbbx_output_no
            // 
            this.cmbbx_output_no.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_output_no.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbbx_output_no.FormattingEnabled = true;
            this.cmbbx_output_no.Location = new System.Drawing.Point(65, 20);
            this.cmbbx_output_no.Name = "cmbbx_output_no";
            this.cmbbx_output_no.Size = new System.Drawing.Size(121, 23);
            this.cmbbx_output_no.TabIndex = 2;
            this.cmbbx_output_no.SelectedIndexChanged += new System.EventHandler(this.cmbbx_output_no_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(10, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "No.";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Black;
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.colum_lbl);
            this.groupBox1.Controls.Add(this.Debug_label3);
            this.groupBox1.Controls.Add(this.Debug_label4);
            this.groupBox1.Controls.Add(this.Debug_label2);
            this.groupBox1.Controls.Add(this.Debug_label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 362);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(790, 135);
            this.groupBox1.TabIndex = 902;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DEBUG";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(456, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 39);
            this.label4.TabIndex = 903;
            this.label4.Text = "�J���� v2";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // colum_lbl
            // 
            this.colum_lbl.AutoSize = true;
            this.colum_lbl.BackColor = System.Drawing.Color.Black;
            this.colum_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.colum_lbl.ForeColor = System.Drawing.Color.White;
            this.colum_lbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.colum_lbl.Location = new System.Drawing.Point(15, 24);
            this.colum_lbl.Name = "colum_lbl";
            this.colum_lbl.Size = new System.Drawing.Size(56, 16);
            this.colum_lbl.TabIndex = 901;
            this.colum_lbl.Text = "label1";
            // 
            // Debug_label3
            // 
            this.Debug_label3.AutoSize = true;
            this.Debug_label3.BackColor = System.Drawing.Color.Black;
            this.Debug_label3.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label3.ForeColor = System.Drawing.Color.White;
            this.Debug_label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label3.Location = new System.Drawing.Point(15, 84);
            this.Debug_label3.Name = "Debug_label3";
            this.Debug_label3.Size = new System.Drawing.Size(56, 16);
            this.Debug_label3.TabIndex = 904;
            this.Debug_label3.Text = "debug1";
            // 
            // Debug_label4
            // 
            this.Debug_label4.AutoSize = true;
            this.Debug_label4.BackColor = System.Drawing.Color.Black;
            this.Debug_label4.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label4.ForeColor = System.Drawing.Color.White;
            this.Debug_label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label4.Location = new System.Drawing.Point(15, 104);
            this.Debug_label4.Name = "Debug_label4";
            this.Debug_label4.Size = new System.Drawing.Size(56, 16);
            this.Debug_label4.TabIndex = 905;
            this.Debug_label4.Text = "debug1";
            // 
            // Debug_label2
            // 
            this.Debug_label2.AutoSize = true;
            this.Debug_label2.BackColor = System.Drawing.Color.Black;
            this.Debug_label2.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label2.ForeColor = System.Drawing.Color.White;
            this.Debug_label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label2.Location = new System.Drawing.Point(15, 64);
            this.Debug_label2.Name = "Debug_label2";
            this.Debug_label2.Size = new System.Drawing.Size(56, 16);
            this.Debug_label2.TabIndex = 903;
            this.Debug_label2.Text = "debug1";
            // 
            // Debug_label1
            // 
            this.Debug_label1.AutoSize = true;
            this.Debug_label1.BackColor = System.Drawing.Color.Black;
            this.Debug_label1.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label1.ForeColor = System.Drawing.Color.White;
            this.Debug_label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label1.Location = new System.Drawing.Point(15, 44);
            this.Debug_label1.Name = "Debug_label1";
            this.Debug_label1.Size = new System.Drawing.Size(56, 16);
            this.Debug_label1.TabIndex = 902;
            this.Debug_label1.Text = "debug1";
            // 
            // btn_setup_import
            // 
            this.btn_setup_import.Location = new System.Drawing.Point(170, 280);
            this.btn_setup_import.Name = "btn_setup_import";
            this.btn_setup_import.Size = new System.Drawing.Size(150, 23);
            this.btn_setup_import.TabIndex = 992;
            this.btn_setup_import.Text = "�t�@�C���C���|�[�g";
            this.btn_setup_import.UseVisualStyleBackColor = true;
            this.btn_setup_import.Click += new System.EventHandler(this.btn_setup_import_Click);
            // 
            // btn_setup_export
            // 
            this.btn_setup_export.Location = new System.Drawing.Point(15, 280);
            this.btn_setup_export.Name = "btn_setup_export";
            this.btn_setup_export.Size = new System.Drawing.Size(150, 23);
            this.btn_setup_export.TabIndex = 991;
            this.btn_setup_export.Text = "�t�@�C���G�N�X�|�[�g";
            this.btn_setup_export.UseVisualStyleBackColor = true;
            this.btn_setup_export.Click += new System.EventHandler(this.btn_setup_export_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btn_setup_init
            // 
            this.btn_setup_init.Location = new System.Drawing.Point(350, 280);
            this.btn_setup_init.Name = "btn_setup_init";
            this.btn_setup_init.Size = new System.Drawing.Size(150, 23);
            this.btn_setup_init.TabIndex = 993;
            this.btn_setup_init.Text = "�ݒ�l������";
            this.btn_setup_init.UseVisualStyleBackColor = true;
            this.btn_setup_init.Click += new System.EventHandler(this.btn_setup_init_Click);
            // 
            // pic_logo
            // 
            this.pic_logo.Image = ((System.Drawing.Image)(resources.GetObject("pic_logo.Image")));
            this.pic_logo.InitialImage = ((System.Drawing.Image)(resources.GetObject("pic_logo.InitialImage")));
            this.pic_logo.Location = new System.Drawing.Point(874, 283);
            this.pic_logo.Name = "pic_logo";
            this.pic_logo.Size = new System.Drawing.Size(186, 50);
            this.pic_logo.TabIndex = 994;
            this.pic_logo.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 500);
            this.Controls.Add(this.pic_logo);
            this.Controls.Add(this.btn_setup_init);
            this.Controls.Add(this.btn_setup_import);
            this.Controls.Add(this.btn_setup_export);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbx_output);
            this.Controls.Add(this.gbx_input);
            this.Controls.Add(this.lbl_FWVersion);
            this.Controls.Add(this.btn_soft_reset);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.Status_C_pb);
            this.Controls.Add(this.Status_NC_pb);
            this.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1080, 538);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "LED Controller for Models Configuration Tool ver ";
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            this.gbx_setting_list.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pattern_set_list)).EndInit();
            this.gbx_input.ResumeLayout(false);
            this.gbx_output.ResumeLayout(false);
            this.gbx_output.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_init_delay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_brightness_off)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_frequency)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_strength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_brightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_off_time)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_setup_val_on_time)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.Button btn_soft_reset;
        private System.Windows.Forms.Label lbl_FWVersion;
        private System.Windows.Forms.GroupBox gbx_setting_list;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.GroupBox gbx_input;
        private System.Windows.Forms.Button btn_sw_setting_set;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbbx_sw_pattern;
        private System.Windows.Forms.GroupBox gbx_output;
        private System.Windows.Forms.Button btn_output_setting_set;
        private System.Windows.Forms.NumericUpDown num_setup_val_off_time;
        private System.Windows.Forms.Label lbl_para2;
        private System.Windows.Forms.NumericUpDown num_setup_val_on_time;
        private System.Windows.Forms.Label lbl_para1;
        private System.Windows.Forms.ComboBox cmbbx_output_pattern;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbbx_output_no;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown num_setup_val_brightness;
        private System.Windows.Forms.Label lbl_para4;
        private System.Windows.Forms.Label lbl_para3;
        private System.Windows.Forms.CheckBox chkbx_loop;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label colum_lbl;
        private System.Windows.Forms.Label Debug_label3;
        private System.Windows.Forms.Label Debug_label4;
        private System.Windows.Forms.Label Debug_label2;
        private System.Windows.Forms.Label Debug_label1;
        private System.Windows.Forms.NumericUpDown num_setup_val_speed;
        private System.Windows.Forms.NumericUpDown num_setup_val_strength;
        private System.Windows.Forms.NumericUpDown num_setup_val_frequency;
        private System.Windows.Forms.NumericUpDown num_setup_val_number;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_para6;
        private System.Windows.Forms.Label lbl_para5;
        private System.Windows.Forms.NumericUpDown num_setup_val_init_delay;
        private System.Windows.Forms.NumericUpDown num_setup_val_brightness_off;
        private System.Windows.Forms.DataGridView dgv_pattern_set_list;
        private System.Windows.Forms.DataGridViewTextBoxColumn no;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chkbx_LED_ON;
        private System.Windows.Forms.DataGridViewTextBoxColumn pattern;
        private System.Windows.Forms.DataGridViewTextBoxColumn setting_value;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btn_setup_import;
        private System.Windows.Forms.Button btn_setup_export;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_setup_init;
        private System.Windows.Forms.PictureBox pic_logo;
    }
}

